---
name: vertical-slice-architecture
description: 'Enforces the 4-layer Vertical Slice Architecture for .NET modular monolith projects. Use when creating new modules, adding endpoints or controllers, writing infrastructure services or repositories, defining domain entities, creating DTOs, setting up cross-module communication (synchronous or event-driven), designing cross-module transactions or sagas, identifying bounded context boundaries, migrating N-tier monoliths or other legacy architectures, planning testing strategy, or reviewing code for architectural boundary violations. Covers the Domain, Public, Infrastructure, and Application layer structure and their dependency hierarchy (Domain at the bottom; each layer may reference any layer below it but never above it); the Public-only cross-module boundary rule; host project structure and composition root; full solution layout; event definitions as public contracts; outbox patterns, idempotency, competing consumers, claim check, message ordering (Sequential Convoy), and dead-letter queue placement for event delivery; Strangler Fig migration guidance including test handling; Saga and application-layer coordination patterns; resilience policy guidance for cross-module calls; caching (Cache-Aside, module cache isolation, invalidation strategies, IMemoryCache vs IDistributedCache); external HTTP integrations and IHttpClientFactory placement; validation placement; testing layout conventions; observability (logging, health checks, tracing); authentication as a module with ICurrentUser; federated identity and external IdP guidance; host-level authorization enforcement; Public contract versioning for breaking changes; HTTP API versioning at the endpoint level; external configuration per module; Result<T> error handling patterns; background jobs, hosted services, and async request-reply; CQRS within a module; module README conventions; and 4 module implementation templates (Simple CRUD with Dapper/MVC, Endpoint-per-Feature with EF Core/FastEndpoints, CQRS with Read/Write Split, and Event-Driven with Outbox pattern) with project structure, class skeletons, DI registration, and migration notes for each.'
---

# Vertical Slice Architecture Enforcement

This skill guides architects and developers in building and reviewing modules that follow the **4-layer Vertical Slice Architecture**. The goal is consistent, decoupled, independently deployable modules where each concern lives in its designated layer.

The core principle is **consistency and intentionality**. Technology choices within each layer are flexible; where things live and how modules communicate are not.

## When to Use This Skill

- Designing or scaffolding a new feature module
- Deciding where a new class, interface, or file belongs
- Adding any endpoint, controller, or route handler
- Writing repositories or services
- Defining domain entities, value objects, or DTOs
- Setting up cross-module communication (synchronous or event-driven)
- Migrating an existing application (N-tier monolith, Big Ball of Mud, or microservices) to this architecture
- Identifying where a bounded context boundary should be drawn
- Reviewing code for boundary violations
- Advising on whether to collapse layers for a small module
- Designing cross-module transactions or sagas
- Planning a testing strategy for a module or the overall solution
- Designing authentication as a module or wiring up `ICurrentUser`
- Deciding where authorization policies should be enforced
- Setting up observability (logging, health checks, distributed tracing) for a module or the host
- Designing a `Result<T>` or exception-based error handling strategy
- Implementing background jobs, hosted services, or async request-reply workflows
- Deciding whether CQRS is appropriate within a module
- Managing breaking changes to a module's Public interfaces or DTOs (contract versioning)
- Structuring the host project (`[Product].Api`) as a composition root
- Understanding the full solution layout across modules, host, shared, and test projects
- Configuring per-module external configuration (connection strings, feature flags, secrets)
- Adding resilience policies (Retry, Circuit Breaker) to cross-module synchronous calls

---

## Architecture Overview

### Full Solution Layout

A realistic solution with two modules, a host, a shared contracts project, and a centralized test project looks like this:

```
[Product].sln
│
├── src/
│   ├── [Product].Api/                   # Host / composition root
│   │   └── Program.cs
│   │
│   ├── [Product].Shared/                # Shared cross-cutting types (optional)
│   │   └── Result.cs, IHasId.cs, etc.
│   │
│   ├── Order/                           # Order bounded context
│   │   ├── Order.Domain/
│   │   ├── Order.Public/
│   │   ├── Order.Infrastructure/
│   │   └── Order.Application/
│   │
│   └── Inventory/                       # Inventory bounded context
│       ├── Inventory.Domain/
│       ├── Inventory.Public/
│       ├── Inventory.Infrastructure/
│       └── Inventory.Application/
│
└── tests/
    └── [Product].Tests/                 # Centralized test project
        ├── Architecture/
        ├── Order/
        │   ├── Unit/
        │   └── Integration/
        └── Inventory/
            ├── Unit/
            └── Integration/
```

This layout is the recommended starting point. It can grow by adding more module folders under `src/` or by splitting a module into its own subdirectory when it grows large enough to warrant one.

---

### The Non-Negotiable Rule

**Modules may only communicate with each other through their `.Public` project.** A module's `.Domain`, `.Infrastructure`, and `.Application` layers are private implementation details. No other module should reference them directly.

Everything else in this architecture is a guideline. The cross-module boundary rule is the invariant that makes the entire structure coherent.

### Module Layer Structure

Every module consists of up to 4 projects:

```
[Module].Domain/           # Domain entities, value objects, enums, domain logic
[Module].Public/           # Cross-module boundary: DTOs and service interfaces
[Module].Infrastructure/   # Repositories, services, data access, external integrations
[Module].Application/      # Endpoint/controller definitions, DI registration, orchestration
```

### Typical Project Dependency Graph

```
[Module].Domain         --> (minimal external dependencies, ideally none or shared contracts only)
[Module].Infrastructure --> [Module].Domain
[Module].Public         --> [Module].Infrastructure, [Module].Domain (or either)
[Module].Application    --> [Module].Domain, [Module].Infrastructure, [Module].Public (any combination)
```

This is a **dependency hierarchy**, not a linear one-to-one chain. Each layer may reference any layer that sits below it in the hierarchy — but never a layer above it. Multiple direct references are normal and expected, particularly in `Application`.

**The hierarchy (top references bottom; never the reverse):**
```
Application   (top — may reference Domain, Infrastructure, and/or Public directly)
    ↑
  Public      (may reference Infrastructure and/or Domain)
    ↑
Infrastructure (references Domain only)
    ↑
  Domain      (bottom — references nothing inside the module)
```

**The role of each layer:**
- `Domain` is the foundation. It has no knowledge of the layers above it.
- `Infrastructure` depends on `Domain` only. It provides concrete data access and service implementations.
- `Public` sits above `Infrastructure`. It exposes the module's service and repository behavior through stable abstractions (interfaces and DTOs). It may reference `Infrastructure` and/or `Domain` as needed.
- `Application` is at the top. It typically references `Domain`, `Infrastructure`, and `Public` directly — for example, to wire up endpoints, register DI, implement providers, and orchestrate across layers. All of these are legitimate direct references.

**Why no layer may reference a layer above it:** Referencing upward creates a circular dependency. For example, `Infrastructure` referencing `Public` would form the cycle `Public → Infrastructure → Public`. This is the one hard constraint on project references within a module.

Cross-module references: `[ModuleB].Application` may reference `[ModuleA].Public` only. It must never reference `[ModuleA].Domain`, `[ModuleA].Infrastructure`, or `[ModuleA].Application`.

The **host application** (`[Product].Api`, etc.) is the **composition root** — it knows about all modules and is permitted to reference any module's `.Public` project directly (for example, to orchestrate calls across modules in middleware or a composition endpoint). This is not a boundary violation because the host is not a peer module.

---

## Layer Guidelines

### 1. Domain Layer (`[Module].Domain`)

**Purpose:** The core business model of the module. Should be expressible without knowledge of databases, HTTP, or frameworks.

**Typical contents:**
```
[Module].Domain/
  Objects/        # Entities, value objects, aggregates
  Enums/          # Domain-specific enumerations
  Abstractions/   # Domain interfaces (e.g., repository contracts if following DDD)
```

**Guidelines:**
- Keep dependencies minimal. This layer ideally depends on nothing except .NET base libraries and possibly a shared contracts project
- No HTTP concerns (no request/response types, no status codes, no IActionResult)
- No direct database access or ORM references unless strictly limited to annotations (e.g., EF Core data annotations for entity configuration)
- Entities represent the ubiquitous language of the domain
- Domain logic and invariants belong here, not in services or controllers

**Example entity (illustrative -- annotation style is one valid approach):**
```csharp
public class OrderItem
{
    public Guid Id { get; set; }
    public Guid OrderId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
}
```

---

### 2. Public Layer (`[Module].Public`)

**Purpose:** The module's stable public boundary. Any other module that needs to interact with this module must do so exclusively through types defined here. This layer creates the seam that allows modules to remain independently changeable.

**Typical contents:**
```
[Module].Public/
  DTO/            # Data Transfer Objects representing the module's public data shapes
  Abstractions/   # Service/provider interfaces consumed by other modules
```

**Guidelines:**
- Contains **interfaces and DTOs only** -- no implementation logic
- DTOs should not expose internal domain entities directly; use purpose-built types (records are ideal for immutable DTOs)
- Interfaces define what other modules can ask this module to do (e.g., query data, trigger an action)
- Interface signatures should use stable, framework-agnostic types (avoid `IQueryable`, `DbSet`, or ORM-specific types in public contracts)
- References `[Module].Infrastructure` (and optionally `[Module].Domain`) so it can reference the concrete service and repository types that underpin its interface definitions. It must never reference `[Module].Application`.
- Provider implementations for these interfaces live in `[Module].Application` -- they delegate to Infrastructure services injected via DI, and are registered there

**Example DTO and interface (illustrative):**
```csharp
// DTO
public sealed record OrderSummaryDto(
    Guid Id,
    string Status,
    decimal Total,
    DateTime CreatedAt);

// Interface exposed to other modules
public interface IOrderSummaryProvider
{
    ValueTask<IReadOnlyList<OrderSummaryDto>> GetAllAsync(CancellationToken ct = default);
    ValueTask<OrderSummaryDto?> GetByIdAsync(Guid id, CancellationToken ct = default);
}
```

#### Collapsing Domain into Public (Small Modules)

For very small modules where the domain model is minimal (one or two simple entities with no significant business logic), it is acceptable to define domain types directly in the `.Public` project and omit the separate `.Domain` project.

**This requires explicit justification.** Before collapsing, an architect must confirm:

1. The module has only one or two domain objects with no meaningful invariants or business logic
2. Those objects are truly stable and unlikely to grow in complexity
3. The team agrees the simplification is appropriate and has documented the decision (e.g., in an ADR, a comment block, or the module README)

When in doubt, use the full 4-project structure. It is far easier to start with separation and merge later than to untangle a Public project that has grown to contain significant domain logic.

---

### 3. Infrastructure Layer (`[Module].Infrastructure`)

**Purpose:** All technical concerns -- data access, external API clients, file I/O, message brokers, caching. Anything that talks to the outside world.

**Typical contents:**
```
[Module].Infrastructure/
  Persistence/     # DbContext, schema configuration, migrations, seed data (if using an ORM)
  Repositories/    # Repository implementations
  Services/        # Infrastructure service implementations (CRUD, external integrations)
  Extensions/      # DI registration helpers (optional -- may live in Application instead)
```

**Guidelines:**
- Data access technology is the architect's choice: EF Core, Dapper, raw ADO.NET, a database project with compiled queries, stored procedures, or any other approach are all valid
- If using an ORM, schema configuration (table names, constraints, indexes) and migrations belong here
- If using a migration-external approach (e.g., a SQL database project, Flyway, DbUp), that tooling's artifacts belong here as well
- Seed data for development or testing belongs here when using an ORM migration; otherwise, seed scripts or fixture files belong alongside the data access tooling
- Service interfaces and their implementations may live in the same file for simplicity, or be split if the interface is large
- All async methods should accept `CancellationToken`
- References only `[Module].Domain`; must not reference `[Module].Public` or `[Module].Application`. (`Public` sits above `Infrastructure` in the dependency hierarchy — Infrastructure referencing Public would create a circular dependency.)
- No HTTP concerns as data-access output types — but external HTTP integrations belong here (see below)

#### External HTTP integrations

When a module calls an external HTTP API (a third-party service, a payment gateway, an upstream REST API), the HTTP client wrapper lives in `[Module].Infrastructure/Services/` or `[Module].Infrastructure/Http/`. This is an external-integration concern, the same as a database repository.

- Use `IHttpClientFactory` (via `AddHttpClient<TClient>()`) rather than constructing `HttpClient` directly. This prevents socket exhaustion and supports configuration of retry/timeout policies.
- Register typed HTTP clients in the module's DI extension method in `[Module].Application/Extensions/`:

  ```csharp
  // In [Module].Application/Extensions/
  public static IServiceCollection AddOrderServices(
      this IServiceCollection services, IConfiguration configuration)
  {
      services.AddHttpClient<IPaymentGatewayClient, PaymentGatewayClient>(client =>
      {
          client.BaseAddress = new Uri(configuration["OrderModule:PaymentGateway:BaseUrl"]!);
      });
      // ...
      return services;
  }
  ```

- The typed client interface and implementation live in `[Module].Infrastructure`. The registration lives in `[Module].Application`.
- If the external API's response shape differs from the module's domain model, use an Anti-Corruption Layer adapter within `Infrastructure` to translate between them.

**Example service structure (illustrative -- EF Core is one valid choice):**
```csharp
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<Order>> GetAllAsync(CancellationToken ct = default);
    Task<Order> CreateAsync(Order order, CancellationToken ct = default);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
}

public class OrderRepository : IOrderRepository
{
    // Implementation using whichever data access tool the architect chose
}
```

---

### 4. Application Layer (`[Module].Application`)

**Purpose:** The hosted component of the module. This layer wires everything together: it defines the HTTP surface (or any other host-facing interface), registers all services with the DI container, and implements provider interfaces from `.Public` so other modules can consume them.

**Typical contents:**
```
[Module].Application/
  Endpoints/        # Endpoint or controller definitions (one folder per feature/use case)
    [Feature]/
      [Feature]Endpoint.cs   (or Controller, Handler, etc.)
      [Feature]Request.cs
      [Feature]Response.cs
  Controllers/      # If using MVC controllers instead of endpoint-per-feature
  Providers/        # Implementations of [Module].Public interfaces
  Extensions/       # DI registration extension methods
  Handlers/         # Event handlers, background job handlers (if applicable)
  Events/           # Application-level events (if applicable)
```

**Guidelines:**
- Any endpoint framework is acceptable: ASP.NET Core controllers, FastEndpoints, Minimal API route handlers, gRPC services, etc. The architect chooses what fits the project
- Co-locate request, response, and handler types for each feature where possible -- this is the "vertical slice" in the name
- This layer is the only place where DI registration extension methods should live. Registration methods should be the primary way the host application adds a module (e.g., `builder.Add[Module]Services()`, `services.Add[Module]Endpoints()`)
- Provider implementations (implementing interfaces from `.Public`) live here because they depend on infrastructure services, which this layer has access to
- Keep endpoints thin: delegate business logic to infrastructure services; do not query the database directly from an endpoint
- Typically references `[Module].Domain`, `[Module].Infrastructure`, and `[Module].Public` directly — all are legitimate. Add whichever project references the layer actually needs; the hierarchy only prohibits referencing layers above `Application` (there are none within a module).
- When consuming another module, references that module's `.Public` project only

**Example illustrating provider implementation (illustrative):**
```csharp
// Implements the interface defined in [Module].Public
public sealed class OrderSummaryProvider(IOrderRepository repository) : IOrderSummaryProvider
{
    public async ValueTask<IReadOnlyList<OrderSummaryDto>> GetAllAsync(CancellationToken ct = default)
    {
        var orders = await repository.GetAllAsync(ct);
        return orders.Select(o => new OrderSummaryDto(o.Id, o.Status.ToString(), o.Total, o.CreatedAt)).ToList();
    }

    public async ValueTask<OrderSummaryDto?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        var order = await repository.GetByIdAsync(id, ct);
        return order is null ? null : new OrderSummaryDto(order.Id, order.Status.ToString(), order.Total, order.CreatedAt);
    }
}
```

**Note on endpoint contracts:** Request and response types are HTTP concerns and belong in `[Module].Application` alongside their endpoints. Do not place them in `[Module].Domain`. This is a common violation to watch for (see Common Violations below).

**Note on validation:** Input validation (shape, required fields, range checks) belongs in `[Module].Application`, co-located with the endpoint it validates -- not in Domain. Domain entities enforce *invariants* (business rules that must always hold), not HTTP input shape. For example, a FluentValidation validator for an endpoint's request type lives next to that endpoint in `Application`; a domain entity's guard clause that prevents a negative `Quantity` lives in the entity itself in `Domain`.

**Note on HTTP API versioning:** When external consumers need multiple API versions simultaneously (e.g., `/api/v1/orders` and `/api/v2/orders`), version routing is an Application-layer and host concern. Route prefixes, version headers, or URL-segment versioning are configured in the endpoint definitions (in `[Module].Application`) and/or via middleware in the host. This is separate from *Public contract versioning* (module-to-module interface compatibility, described in its own section below). A breaking change in the HTTP surface does not necessarily require a new Public contract version, and vice versa.

---

## Cross-Module Communication

When Module B needs data or behavior from Module A:

1. Module A defines an interface in `[ModuleA].Public/Abstractions/` describing what it provides
2. Module A defines DTOs in `[ModuleA].Public/DTO/` for the data shapes it exposes
3. Module A implements that interface in `[ModuleA].Application/Providers/`
4. Module A registers the implementation in its DI extension method
5. Module B adds a project reference to `[ModuleA].Public`
6. Module B injects the interface where needed

**Module B (a peer module) must never reference** `[ModuleA].Domain`, `[ModuleA].Infrastructure`, or `[ModuleA].Application`. The host application is not subject to this restriction — it is the composition root and may reference any module's `.Public` project directly.

### Resilience for cross-module calls

When Module B calls Module A's Public interface synchronously, that call is a network-like dependency within the process boundary. If Module A is slow, overloaded, or failing, Module B can be affected. Apply resilience patterns where appropriate:

- **Retry** — transient failures (e.g., a database spike inside Module A) may succeed on a second attempt. Configure retry policies with exponential backoff.
- **Circuit Breaker** — if Module A is consistently failing, stop calling it immediately instead of piling on load. Open the circuit after a threshold of failures; probe for recovery periodically.
- **Bulkhead** — isolate Module A's call path so that a slow Module A does not exhaust shared thread-pool or connection-pool resources and drag down Module B's other operations.

**Placement is an architectural decision.** Common options include:

- Configuring resilience in Module B's Application layer, wrapping calls to Module A's injected interface
- Configuring resilience at the host level (e.g., via a decorated registration in the host's DI configuration) so Module B's code stays unaware of retry logic

Whichever approach is chosen, document it consistently across the solution. Mixing per-call and host-level policies in the same codebase is a common source of confusion.

---

## Orchestration and Hosting

Some form of orchestration is strongly recommended to make the modular structure easily runnable and testable as a whole. The choice of orchestration tool is the architect's decision:

- **Aspire** -- well-suited for .NET-native modular monoliths; provides service discovery, telemetry, container lifecycle management, and integration test support
- **Docker Compose** -- a portable, framework-agnostic option; works well when the team is not .NET-exclusive
- **Other tools** (Tilt, Helm for local dev, Nomad, etc.) -- all valid depending on the deployment target

Regardless of the orchestration tool chosen, each module should expose DI registration extension methods that the host application (`[Product].Api`, `[Product].Service`, etc.) can call to register that module's components.

---

## Host Project Structure

The host application (`[Product].Api`) is the **composition root** -- the single entry point that knows about all modules and wires them together. Modules do not know about each other except through their Public contracts; only the host knows about all of them.

### What belongs in the host

```
[Product].Api/
  Program.cs           # Application entry point; module registration; middleware pipeline
  appsettings.json     # Root configuration file; module-specific sections nested here
  appsettings.*.json   # Environment-specific overrides
```

### Responsibilities of the host

- **Module registration** — call each module's DI extension method (e.g., `builder.Services.AddOrderServices(...)`)
- **Middleware pipeline** — configure authentication middleware, exception handling, request logging, etc.
- **Authorization policy registration** — declare all authorization policies and requirements here, not inside modules
- **Global telemetry** — wire up OpenTelemetry (or equivalent): exporters, meters, tracer providers, `ActivitySource` registrations
- **Health endpoint** — map `/health` (or equivalent) and aggregate all module-registered health checks
- **Gateway/routing concerns** — if using Gateway Aggregation or BFF patterns, the aggregation logic lives here (or in a dedicated gateway project), not inside individual modules

### What does NOT belong in the host

- Business logic -- the host orchestrates but does not implement domain behavior
- Direct database access -- the host has no ORM context of its own (unless it owns a cross-cutting store such as an audit log)
- Module-internal types -- the host may reference module `.Public` projects only (same rule as any other consumer)

### Module configuration

Each module reads its own named configuration section from the host's configuration file:

```json
{
  "OrderModule": {
    "ConnectionString": "...",
    "MaxActiveOrders": 100
  },
  "InventoryModule": {
    "ConnectionString": "...",
    "LowStockThreshold": 10
  }
}
```

The module's DI extension method accepts an `IConfiguration` (or a pre-bound strongly-typed options object) and binds its own section:

```csharp
// In [Module].Application/Extensions/
public static IServiceCollection AddOrderServices(
    this IServiceCollection services,
    IConfiguration configuration)
{
    var options = configuration
        .GetSection("OrderModule")
        .Get<OrderModuleOptions>() ?? new OrderModuleOptions();

    services.AddSingleton(options);
    // ... rest of registration
    return services;
}
```

Secrets (connection strings, API keys) should be injected into the host's configuration via the environment's secret management mechanism (environment variables, Azure Key Vault, AWS Secrets Manager, etc.) and consumed through the same `IConfiguration` abstraction. Modules do not reference secret stores directly.

---

## Enforcing Architectural Boundaries

The cross-module boundary rule should ideally be enforced automatically, not just by convention. Options include:

- **NetArchTest** (.NET) -- write test rules that assert no module's non-Public layers reference another module's non-Public layers. Example:

  ```csharp
  // Assert that Todo.Infrastructure does not reference Weather.Infrastructure
  Types.InAssembly(Assembly.Load("Todo.Infrastructure"))
      .ShouldNot()
      .HaveDependencyOn("Weather.Infrastructure")
      .GetResult()
      .IsSuccessful.ShouldBeTrue();
  ```

- **ArchUnitNET** -- an alternative with richer rule expression for .NET
- **Compiler-enforced via project references** -- simply not adding a project reference is the most immediate enforcement; tooling-based checks add a safety net against future accidental additions
- **Custom Roslyn analyzers** -- for teams wanting IDE-level feedback

Whichever approach is used, the rule being enforced is always the same: **cross-module references are only valid to a module's `.Public` project**.

---

## Shared Contracts (Optional)

A shared contracts project (e.g., `[Product].Shared`) can be useful for types that are genuinely cross-cutting and do not belong to any single module: common response envelope types, shared abstractions (`IHasId`, `IAuditable`, `IConcurrency`), guard utilities, common error types, etc.

Shared types are **encouraged where they reduce duplication and add consistency**, but they are not required. Do not force unrelated concerns into a shared project simply to avoid creating one file per module.

If the project uses a shared response envelope (e.g., `ApiResponse<T>` wrapping every HTTP response), all modules should use it consistently. If no such envelope exists, modules may define their own response conventions as long as they are consistent within the module.

---

## Observability

Observability is a **host-level concern**. The host application is responsible for configuring global telemetry pipelines (tracing exporters, metrics sinks, log sinks, etc.). Individual modules are not responsible for configuring these pipelines.

### Logging

- All layers may use `ILogger<T>` (injected via DI); this is the only logging abstraction modules should use
- Do not reference a specific logging framework (Serilog, NLog, etc.) directly from module code; reference it only in the host
- Log meaningful events at appropriate levels; avoid logging inside tight loops or on the happy path at levels above `Debug`

### Distributed tracing and metrics

- Modules may create `ActivitySource` instances for custom spans, but they must not configure exporters themselves
- The host wires up OpenTelemetry (or equivalent) and registers all module `ActivitySource` names it wants to observe
- Modules may expose constants for their `ActivitySource` name (e.g., in their `.Public` project) so the host can reference them without hardcoding strings

### Health checks

- Each module should register its own health check(s) in its DI extension method:

  ```csharp
  // In [Module].Application/Extensions/
  public static IServiceCollection AddOrderServices(this IServiceCollection services, ...)
  {
      services.AddHealthChecks()
          .AddCheck<OrderDbHealthCheck>("orders-db");
      // ...
      return services;
  }
  ```

- The host maps the `/health` endpoint and aggregates all registered health checks
- Health check implementations live in `[Module].Infrastructure` (they are a technical/data-access concern)

---

## Authentication and Authorization

Authentication and authorization are **separated concerns** at the architectural level.

### Authentication: treat as a module

Authentication is a first-class bounded context. It has its own domain (identity, tokens, sessions), its own data store, and its own lifecycle. Treat it as a module:

```
Auth.Domain/          # Identity entity, session, token value objects
Auth.Public/          # ICurrentUser interface, identity DTOs
Auth.Infrastructure/  # Token store, password hashing, external IdP integration
Auth.Application/     # Login/logout endpoints, DI registration
```

Other modules consume the authenticated identity by injecting `ICurrentUser` (defined in `Auth.Public`):

```csharp
// In Auth.Public/Abstractions/
public interface ICurrentUser
{
    Guid UserId { get; }
    string Email { get; }
    IReadOnlyList<string> Roles { get; }
    bool IsAuthenticated { get; }
}
```

### Federated identity (external IdP)

When the application delegates authentication to an external identity provider (Azure AD / Entra ID, Auth0, Duende IdentityServer, Okta, or any OAuth 2.0 / OpenID Connect provider), a full `Auth` module is often unnecessary or significantly reduced in scope:

- **JWT middleware in the host** validates the token and populates claims. The host registers the authentication middleware (`AddAuthentication().AddJwtBearer(...)`) in its DI configuration.
- **`ICurrentUser` remains the abstraction** other modules depend on. Instead of a full Auth module implementing it, a thin host-level or shared implementation reads the claims from `IHttpContextAccessor` and exposes them through `ICurrentUser`:

  ```csharp
  // Host or [Product].Shared — registered in host DI as Scoped
  public sealed class ClaimsPrincipalCurrentUser(IHttpContextAccessor accessor) : ICurrentUser
  {
      public Guid UserId => Guid.Parse(accessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? Guid.Empty.ToString());
      public string Email => accessor.HttpContext?.User.FindFirstValue(ClaimTypes.Email) ?? string.Empty;
      public IReadOnlyList<string> Roles => accessor.HttpContext?.User.FindAll(ClaimTypes.Role).Select(c => c.Value).ToList() ?? [];
      public bool IsAuthenticated => accessor.HttpContext?.User.Identity?.IsAuthenticated ?? false;
  }
  ```

- **When to still build a full Auth module:** Build one when the application manages its own credential store (custom username/password, API keys, token issuance), handles token refresh logic, or maintains user profile data that is not sourced from the IdP.
- **When to use a thin implementation:** Use a `ClaimsPrincipalCurrentUser` adapter (registered in the host or `[Product].Shared`) when the IdP owns all identity concerns and the application is a pure consumer of tokens.

The `ICurrentUser` interface contract does not change between the two approaches — modules remain unaware of whether authentication is handled by an internal Auth module or an external IdP.

### Authorization: host-level enforcement

Authorization policy enforcement (e.g., "this endpoint requires the Admin role") is a **host-level cross-cutting concern**, not a module-level concern:

- Policies are registered in the host application, not inside individual modules
- Modules do not enforce authorization policies themselves; they trust the host to have done so before the request reaches the module
- A module may *read identity* (via `ICurrentUser`) to personalize a response or to record who performed an action, but it must not be the enforcement point for access control

This separation means:
- Swapping the authorization framework (e.g., policy-based → ABAC) is a host-level change, not a module-level change
- Modules remain testable in isolation without needing to configure authorization infrastructure

**Common violation to flag:** A module that checks roles or policies directly via ASP.NET Core authorization attributes on its endpoints is not wrong per se, but the *policies themselves* must be registered at the host, not inside the module's DI extension.

---

## Public Contract Versioning

Public interfaces and DTOs are the module's stable boundary. Once consumed by another module, changes must be managed carefully.

### Additive vs. breaking changes

| Change type | Example | Safe? |
|---|---|---|
| Add optional member to DTO | New nullable property | Usually safe (deserializes as null) |
| Add overload to interface | New method with default impl | Safe |
| Rename a DTO property | `CustomerId` → `ClientId` | Breaking |
| Remove a DTO property | Remove `Status` field | Breaking |
| Change a method signature | Add required parameter | Breaking |
| Change return type | `Task<T>` → `ValueTask<T>` | Breaking |

### Strategy: namespace or project versioning

For breaking changes, the recommended approach is to version by namespace or project:

```
Order.Public/
  V1/
    OrderSummaryDto.cs
    IOrderSummaryProvider.cs
  V2/
    OrderSummaryDto.cs          # New shape
    IOrderSummaryProvider.cs    # Updated contract
```

Or, for larger breaks, a separate project:

```
Order.Public.V2/      # New project; consumers opt in explicitly
```

**Rules:**
- The previous version remains intact and functional until all consumers have migrated
- Both versions may exist simultaneously during the migration window
- Document the deprecation timeline in the module README or an ADR
- Once all consumers have migrated, remove the old version in a coordinated change

Avoid silently changing existing public types. If a consumer is broken by a change to a Public contract, that is a cross-module boundary violation introduced by the producer.

---

## Error Handling

### Result pattern

If the project uses a `Result<T>` type (or equivalent) to communicate success/failure without exceptions, it **must live in the shared contracts project** (`[Product].Shared`) — not in any single module's Public or Domain project. This makes it available to all modules and the host without introducing circular dependencies.

```csharp
// In [Product].Shared/
public sealed class Result<T>
{
    public bool Succeeded { get; }
    public T? Value { get; }
    public string? Error { get; }

    public static Result<T> Success(T value) => new(true, value, null);
    public static Result<T> Failure(string error) => new(false, default, error);

    private Result(bool succeeded, T? value, string? error) { ... }
}
```

### Public interface contracts: document throw vs. Result

Every interface in `[Module].Public` should clearly communicate its failure contract. Choose one approach per project and be consistent:

- **Exception-based:** The method throws on failure. Document what exceptions callers should expect in XML doc comments.
- **Result-based:** The method returns `Result<T>`. Callers always get a success/failure indicator without needing try/catch.

Do not mix both approaches within the same Public interface (e.g., some methods throw and others return Result).

### Domain exceptions vs. Result

- Use **domain exceptions** for invariant violations that represent programmer error or corrupted state (e.g., constructing an entity with invalid data). These should not be caught and returned to the caller as normal control flow.
- Use **Result** (or `OneOf`, `ErrorOr`, etc.) for expected failure paths that are part of normal business flow (e.g., "item not found", "insufficient inventory").

---

## Background Jobs and Hosted Services

Long-running background work belongs in `[Module].Application`, implemented as `BackgroundService` or any equivalent background job abstraction chosen by the architect (Hangfire jobs, Quartz.NET jobs, etc.).

### Placement rules

- `BackgroundService` implementations: `[Module].Application/Handlers/` or `[Module].Application/Jobs/`
- Background jobs may inject and consume other modules' Public interfaces via DI — this is the correct way for a background job to interact with another module
- Background jobs must not reference another module's non-Public layers directly

### Registration

Register background services in the module's DI extension method alongside endpoints and providers:

```csharp
public static IServiceCollection AddOrderServices(this IServiceCollection services, ...)
{
    services.AddHostedService<OrderExpiryBackgroundJob>();
    // ... rest of registration
    return services;
}
```

### Interaction with events

Background jobs are a natural place to consume events from a message broker. Place the broker-specific consumer (e.g., a MassTransit consumer, a Kafka consumer loop) in `Application` or `Infrastructure` as appropriate for the chosen library:

- If the consumer class is framework-agnostic and contains business logic → `Application`
- If the consumer class is tightly coupled to the broker library → `Infrastructure`

### Async Request-Reply

When an HTTP endpoint triggers a long-running operation (one that cannot complete within a normal request timeout), use the **Async Request-Reply pattern**:

1. The endpoint enqueues the job (via a background job abstraction in `Application`) and immediately returns **HTTP 202 Accepted** with a `Location` header pointing to a status endpoint
2. A `BackgroundService` or job runner processes the work asynchronously
3. The status endpoint (also in `[Module].Application`) reports progress or the final result once the job completes

The job's state (queued, in-progress, completed, failed) is stored in `[Module].Infrastructure`. The status endpoint reads this state and returns it to the caller. Correlation IDs tie the original request to its job record.

---

## CQRS Within a Module

CQRS (Command Query Responsibility Segregation) is an **optional pattern** within a module. Use it when read and write workloads diverge significantly enough to warrant separate models, queries, or data stores.

CQRS is a module-internal concern. It does not change how other modules interact with this module (they still go through `.Public`).

### When to consider CQRS within a module

- Read queries are complex aggregations that are awkward to express through the same domain model used for writes
- Read and write paths have meaningfully different performance characteristics (e.g., writes go through strict aggregate logic; reads are simple projections)
- The module has a natural command/event boundary that maps well to separate read and write sides

### Where the pieces live

```
[Module].Infrastructure/
  Persistence/
    WriteDb/          # Write-side DbContext, aggregates, migrations
    ReadDb/           # Read-side: projection tables, read models, query services
  Repositories/       # Write-side repositories
  Queries/            # Read-side query services or projectors
```

### Public layer stays clean

The Public layer does not expose the internal CQRS split. DTOs returned via `[Module].Public` interfaces may be sourced from either the read or write side -- callers do not know or care.

### Read-side patterns

Common patterns for the read side within a module:

- **Materialized View** — maintain a pre-computed projection table that is refreshed asynchronously when the write side changes. Ideal when queries involve expensive joins or aggregations over the write model. Projectors live in `[Module].Infrastructure/Persistence/ReadDb/`.
- **Index Table** — create secondary lookup structures (additional tables or document indexes) over write-side data to support query patterns the primary schema does not serve efficiently. Also an `Infrastructure` concern.

Both patterns trade storage cost for query performance. Document the chosen approach in the module README or a CQRS decision record.

### Event sourcing

If using event sourcing, the event store and projectors are `Infrastructure` concerns. Domain events (the source of truth) are internal to the module. Only events that cross module boundaries belong in `[Module].Public/Events/`.

---

## Caching

Caching is an **Infrastructure concern**. Cache implementations (in-memory, distributed, hybrid) live in `[Module].Infrastructure`. Modules access cache through injected abstractions, not through static or global cache singletons.

### Layer placement

- Cache implementations: `[Module].Infrastructure/Caching/` or alongside the service they accelerate (`[Module].Infrastructure/Services/`)
- Cache interface (if abstracting the cache): `[Module].Infrastructure/Caching/IOrderCache.cs` (module-internal only — not in Public)
- DI registration: module's DI extension method in `[Module].Application/Extensions/`

### Cache-Aside pattern

The Cache-Aside pattern is the standard approach for read-heavy data within a module:

1. Check the cache first
2. On cache miss, load from the data store and populate the cache
3. On write, invalidate or update the cache entry

```csharp
// In [Module].Infrastructure — illustrative, technology-agnostic
public class CachedOrderRepository(IOrderRepository inner, IMemoryCache cache) : IOrderRepository
{
    public async Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        if (cache.TryGetValue(CacheKey(id), out Order? cached))
            return cached;

        var order = await inner.GetByIdAsync(id, ct);
        if (order is not null)
            cache.Set(CacheKey(id), order, TimeSpan.FromMinutes(5));

        return order;
    }

    private static string CacheKey(Guid id) => $"order:{id}";
}
```

### Module cache isolation

**A module must not share a cache namespace with another module.** Use a module-specific key prefix (e.g., `order:`, `inventory:`) to prevent key collisions and implicit coupling. Even when the same distributed cache instance (Redis, etc.) is used across the host, each module's cache entries are logically isolated.

Cross-module data must not be served from another module's cache — it must always go through the owning module's Public interface.

### Invalidation strategy

Choose a cache invalidation strategy appropriate to the module's consistency requirements:

| Strategy | When to use |
|---|---|
| **Time-based expiry (TTL)** | Eventual consistency is acceptable; data changes infrequently |
| **Write-through invalidation** | Cache entry is evicted or updated on every write to the data store |
| **Event-driven invalidation** | A domain event (e.g., `OrderUpdatedEvent`) triggers cache eviction in a handler |

Prefer time-based expiry for simplicity. Use event-driven invalidation only when the added complexity is justified by consistency requirements.

### Distributed cache vs. in-memory cache

- **`IMemoryCache`** — in-process only; not suitable for horizontally scaled deployments (each instance has its own cache state). Use for single-instance deployments or non-critical caches.
- **Distributed cache (`IDistributedCache`)** — Redis, SQL Server, or other out-of-process store. Required for scaled-out deployments where all instances must see the same cached data.

Register the appropriate implementation in the host, not in the module. Modules inject `IMemoryCache` or `IDistributedCache` (the .NET abstractions); the host decides which backing store to use.

### Common caching violations to flag

- A module exposing its cache interface in `.Public` (cache internals must not be accessible to other modules)
- Two modules sharing a key prefix (creates hidden coupling through the cache)
- Caching a domain entity that contains another module's data (the cached shape should match the module's own domain model only)
- Caching response DTOs from another module's Public interface (the owning module owns the cache lifetime for its own data)

---

## Module README Convention

A module README is **encouraged but not required**. When present, it should be placed at the module root (e.g., alongside the `[Module].Domain`, `[Module].Public`, etc. projects) as `README.md`.

### Suggested minimum content

- **Bounded context rationale:** Why does this module exist as a separate module? What does it own?
- **Ubiquitous language:** Key domain terms and their meanings within this module's context
- **Event catalog:** Events published by this module (if any), with payload descriptions
- **Collapsed layer decisions:** If Domain was collapsed into Public, document the three-criteria justification here
- **CQRS decision:** If CQRS is used, document why
- **ADR links:** References to relevant Architectural Decision Records
- **Deprecation notices:** Any Public interface versions that are deprecated and the migration timeline

A README becomes especially important when a module is owned by a separate team or is expected to be reused across products.

---

## Common Violations to Flag

- Any module's non-Public layer referencing another module's non-Public layer (the hard rule)
- HTTP request/response types defined in `[Module].Domain` (these are Application concerns)
- Input validation logic defined in `[Module].Domain` (input shape validation belongs in Application; only business invariants belong in Domain)
- Direct database access from an endpoint or controller (should go through a service or repository)
- Provider interface returning internal domain entities instead of DTOs (leaks implementation)
- Collapsing Domain into Public without documented justification
- Business logic in an endpoint that belongs in a domain or infrastructure service
- Missing or inconsistent DI registration (module components not registerable via extension methods)
- Architecture boundary enforcement not covered by automated tests
- Event definitions placed outside the owning module's `.Public` project (unless using a dedicated shared events project with documented justification)
- Module missing health check registration in its DI extension method
- `Result<T>` or equivalent defined inside a module's `Domain` or `Public` project instead of the shared contracts project
- Authorization policy enforcement logic inside a module (policies belong at the host; modules only read identity via `ICurrentUser`)
- A module directly referencing a concrete logging framework instead of `ILogger<T>` from `Microsoft.Extensions.Logging`
- Breaking change made silently to a Public interface or DTO without introducing a versioned namespace or project
- `BackgroundService` or job class placed in `Infrastructure` when it contains business orchestration logic (should be in `Application`)
- A module's `ActivitySource` exporter configured inside the module (telemetry pipeline configuration belongs in the host)
- Shared project (`[Product].Shared`) containing module-specific types or references to any module project (the shared project should contain only genuinely cross-cutting, module-agnostic types; module-specific concerns create hidden coupling through the shared layer)
- Any layer referencing a layer above it in the dependency hierarchy (e.g., `Infrastructure` referencing `Public`, `Domain` referencing `Infrastructure`). The hierarchy is `Domain` at the bottom, `Application` at the top — each layer may reference anything below it, but never anything above it, as that creates a circular dependency

---

## Module Boundary Identification

Before building a module, determine where the boundary belongs. This architecture uses **bounded contexts** as the primary signal for module boundaries.

### Signals that justify a new module

- **Bounded context boundary:** The capability belongs to a distinct area of the domain with its own ubiquitous language, its own lifecycle for its core entities, and its own team or ownership. If the same word (e.g., "Customer") means meaningfully different things in two contexts, those contexts should be separate modules.
- **Independently changeable:** The capability should be able to evolve -- schema, logic, API surface -- without requiring changes to other modules' internals.
- **Separate data ownership:** The module owns its own database schema, connection string, or at minimum its own set of tables. Shared tables across modules are a strong signal that the boundary is in the wrong place.
- **Team or ownership boundary:** Different teams own the capability. Module boundaries should align with team boundaries to minimize coordination overhead (Conway's Law).

### Signals that suggest staying in an existing module

- The new capability shares most of its domain entities and invariants with an existing module
- The new capability is a new *endpoint* on an existing aggregate (e.g., a new way to query orders is not a new module -- it is a new endpoint in the Order module)
- The capability has no meaningful independent lifecycle

### Recommended process for boundary identification

1. **Event storming or context mapping** -- walk through domain events to find natural seams. Commands and events that cluster around the same aggregate or lifecycle belong in the same module.
2. **Ubiquitous language audit** -- if the same term means different things across teams or subdomains, that is a strong bounded context seam.
3. **Dependency heat map** -- if two potential modules would always change together and always reference each other's internals, they may be the same bounded context.

When in doubt, start with fewer, larger modules and extract later. Premature decomposition is harder to undo than late extraction.

---

## Module Implementation Templates

These templates are **worked examples of the architecture applied with specific technology choices** — they are not prescriptions. If your team prefers a different ORM, endpoint library, or messaging approach, the architectural rules (layer boundaries, dependency hierarchy, Public-only cross-module rule) remain the same; only the technology within each layer changes.

Each template covers: when to choose it, project structure, project reference diagram, key class skeletons per layer, DI registration, migration notes (N-tier, Big Ball of Mud, microservices), and common mistakes.

### Template Selection Guide

| # | Template | Data Access | Endpoint Style | CQRS | Best For |
|---|---|---|---|---|---|
| 1 | [Simple CRUD](references/template-01-simple-crud.md) | Dapper | MVC Controllers | No | Small or stable modules; lowest ceremony; ideal migration starting point |
| 2 | [Endpoint-per-Feature](references/template-02-endpoint-per-feature.md) | EF Core | FastEndpoints / Minimal API | No | Standard new modules; vertical slice most clearly visible here |
| 3 | [CQRS with Read/Write Split](references/template-03-cqrs-read-write-split.md) | EF Core (writes) + Dapper (reads) | FastEndpoints | Yes | Read-heavy or complex modules; performance-sensitive query paths |
| 4 | [Event-Driven / Async](references/template-04-event-driven.md) | EF Core + Outbox | Minimal API | Optional | Modules that publish integration events; async workflows; Saga participants |

### Choosing between templates

- **Start with Template 1 or 2** for any new module. Introduce additional complexity only when there is a demonstrated need.
- **Upgrade to Template 3** when read query complexity justifies separating the read and write paths — not before.
- **Upgrade to Template 4** when the module must publish events to other modules or external systems with at-least-once delivery guarantees.
- **Mix templates across modules** — each module in a solution can use a different template. The Public-only boundary rule ensures that the internal implementation choice is invisible to other modules.

---

## Migration Guidance

This architecture is designed to accommodate migration from any starting point. The recommended strategy is the **Strangler Fig pattern**: incrementally extract capabilities into well-formed modules without requiring a big-bang rewrite.

### Supported starting points

- **Traditional N-tier monolith** (Controllers / Services / Repositories): The most common migration source. Extract one bounded context at a time into a module, starting with the least entangled capability.
- **Big Ball of Mud** (no clear structure): Identify natural seams via event storming or domain expert interviews before beginning extraction. Stabilize the anti-corruption layer before moving logic.
- **Microservices consolidation** (bringing services into a modular monolith): Treat each incoming microservice as a candidate module. Evaluate whether multiple services belong to the same bounded context and should be merged, or whether they each warrant their own module.

### Migration phases (Strangler Fig)

```
Phase 1: Identify a bounded context with stable, well-understood behavior
Phase 2: Create the 4-project module structure alongside the legacy code
Phase 3: Implement the new module targeting the same data store (or a migrated one)
Phase 4: Route new traffic to the module; legacy code still serves existing traffic
Phase 5: Migrate remaining traffic; delete the legacy code
Phase 6: Repeat for the next bounded context
```

**Handling existing tests during migration:** Leave existing tests in place while the legacy code they cover is still active. Do not delete or migrate them until the module extraction is complete and the legacy code is fully retired. Once a bounded context has been fully extracted and the legacy code removed, migrate the relevant tests into the centralized test project (`[Product].Tests/[Module]/`) -- updating test setup and assertions to match the new module's interfaces. Add new architecture boundary tests to the `Architecture/` folder as each module is completed.

### Anti-Corruption Layer

When migrating, the new module must not be polluted by the legacy model's data shapes or naming conventions. Use an **Anti-Corruption Layer (ACL)** to translate between the legacy model and the new module's domain model:

- Place ACL adapters in `[Module].Infrastructure` (they are a technical integration concern)
- ACL types should translate incoming legacy shapes into the module's own domain types -- they must not expose legacy types to the rest of the module
- Once the legacy code is fully retired, remove the ACL

### Handling shared tables during migration

Shared database tables (where multiple legacy components write to the same table) are the hardest migration scenario. Options in increasing order of effort:

1. **Designate an owner module** -- one module owns the table and all write paths; other legacy components temporarily call that module's public interface to write (even if that requires a new internal API endpoint for the migration period)
2. **Duplicate and sync** -- both old and new code write to separate tables; a sync job keeps them consistent until old code is retired
3. **Schema split** -- decompose the shared table into module-owned tables before migrating logic

Avoid option 3 unless options 1 or 2 are not feasible; schema splits are risky and time-consuming.

---

## Events and Async Cross-Module Communication

Synchronous interface-based communication (via Public interfaces) is the default. For cases where synchronous coupling is inappropriate -- high latency operations, fan-out notifications, decoupled workflows -- **domain events** provide the alternative.

### Where event definitions live

Event definitions are **part of the Public contract** of the publishing module. Place them in `[Module].Public/Events/`:

```
[Module].Public/
  DTO/             # Query/read data shapes
  Abstractions/    # Synchronous service interfaces
  Events/          # Domain event definitions published by this module
```

Other modules that subscribe to an event add a project reference to the publishing module's `.Public` project -- the same rule as synchronous cross-module communication.

**Example event definition (illustrative):**
```csharp
// In Order.Public/Events/
public sealed record OrderPlacedEvent(
    Guid OrderId,
    Guid CustomerId,
    decimal Total,
    DateTime PlacedAt);
```

### Publishing and subscribing

- The publishing module raises events from its Application layer (e.g., after a successful write in a service or endpoint)
- The subscribing module handles events in `[Module].Application/Handlers/`
- The event bus or broker infrastructure is a technical concern -- place broker-specific code (MassTransit consumers, MediatR handlers, etc.) in `Application` or `Infrastructure` as appropriate for the chosen library
- Event handler failures must not silently corrupt state. Use **outbox patterns**, **idempotency keys**, or **dead-letter queues** depending on the broker:
  - **Outbox pattern:** The publishing module writes events to an outbox table (in `Infrastructure`) in the same database transaction as the state change; a background job then forwards them to the broker. This guarantees at-least-once delivery.
  - **Idempotency keys:** Each event carries a unique identifier (e.g., `EventId`). The subscribing handler records processed event IDs in its own store (in `Infrastructure`) and skips re-processing if the ID has already been seen. This turns at-least-once delivery into effectively-once processing.
  - Idempotency enforcement logic lives in `[Module].Infrastructure`, near the data-access boundary -- not in the Application handler itself.
  - **Competing consumers:** In a scaled-out deployment, multiple instances of the host will race to consume events from the same queue or topic. This is the primary reason idempotency is non-negotiable -- any given event may be delivered to more than one instance. Design every event handler to be safe to execute more than once with the same input.
  - **Dead-letter queues (DLQ):** When a message cannot be processed after the maximum retry attempts, the broker moves it to a dead-letter queue. Broker-specific DLQ mechanics (registering the DLQ, configuring retry counts) live in `[Module].Infrastructure`. The handler that re-processes or alerts on dead-lettered messages lives in `[Module].Application/Handlers/`.

### Message ordering

By default, most message brokers do not guarantee global ordering across all consumers. When a module must process events in a defined sequence — for example, `OrderPlaced` must always be processed before `OrderShipped` for the same order — use the **Sequential Convoy pattern**:

- Group related messages using a **session ID or partition key** (e.g., the `OrderId`) so that all events for the same aggregate are routed to the same consumer instance or partition
- Within each partition or session, events are processed sequentially in arrival order
- Independent groups (different `OrderId` values) are still processed in parallel, preserving throughput

**Placement:** Partition key assignment is a broker configuration concern and belongs in `[Module].Infrastructure`. Session-aware consumers or partition-aware handlers are configured there as well.

**When ordering is not required:** If events for the same aggregate can be processed in any order (because the handler is fully idempotent and stateless), do not impose ordering constraints. Unnecessary ordering reduces throughput and complicates scaling.

### Claim Check for large event payloads

When an event payload is too large for the message broker (e.g., a file attachment, a bulk export result, or a large JSON document), use the **Claim Check pattern**:

1. The publishing module stores the payload in a blob store, object storage, or database (in `Infrastructure`)
2. The event published to the broker contains only a reference (a URI or an ID) to the stored payload
3. The subscribing handler retrieves the full payload from the store using the reference

Place payload storage and retrieval in `[Module].Infrastructure`. The event definition in `[Module].Public/Events/` carries only the reference, not the payload itself.

### When to use events vs. interfaces

| Use synchronous interface | Use events |
|---|---|
| Module B needs a synchronous result from Module A | Module A wants to notify interested parties without knowing who they are |
| The operation is a query | The operation is a side effect (e.g., send email, update a read model) |
| Tight coupling is acceptable (host orchestration) | Loose coupling is required |
| Failure of Module A should fail Module B's request | Module A should not care whether Module B succeeds |

---

## Cross-Module Transactions

Distributed transactions (two-phase commit across module boundaries) are strongly discouraged. Prefer eventual consistency. Where strong consistency is genuinely required, use one of the patterns below.

### Application-layer coordination (preferred for simple cases)

The host application or a coordination service orchestrates calls across module Public interfaces within a single request. This is suitable when:

- The number of modules involved is small (2-3)
- Failure handling is straightforward (one module failing cancels the whole operation)
- The operation does not need to be retried independently

**Illustrative example:**

```csharp
// In the host or a shared coordination service
public async Task<Result> PlaceOrderWithInventoryReservationAsync(PlaceOrderRequest request, CancellationToken ct)
{
    // Step 1: Reserve inventory via Inventory module's public interface
    var reservation = await _inventoryProvider.ReserveAsync(request.Items, ct);
    if (!reservation.Succeeded)
        return Result.Failure("Inventory unavailable");

    // Step 2: Place the order via Order module's public interface
    var order = await _orderProvider.PlaceAsync(request, reservation.ReservationId, ct);
    if (!order.Succeeded)
    {
        // Compensate: release the reservation
        await _inventoryProvider.ReleaseAsync(reservation.ReservationId, ct);
        return Result.Failure("Order placement failed");
    }

    return Result.Success(order.OrderId);
}
```

This is simple to reason about but does not survive process crashes mid-flight. Use it for operations where the window of inconsistency is acceptable.

### Saga pattern (for reusable or complex orchestration)

Use the Saga pattern when:

- The transaction spans more than 2-3 modules
- The coordination logic is reused across multiple callers
- Individual steps need independent retry, timeout, or compensation logic
- The process must survive process restarts (durable execution)

**Orchestration Saga** -- a central saga orchestrator calls each module's Public interfaces in sequence and executes compensating actions on failure. The orchestrator's state machine lives in a dedicated project (e.g., `[Product].Sagas` or inside the most relevant module's Application layer):

```csharp
// Illustrative Saga state (using any saga/workflow library)
public class PlaceOrderSaga
{
    public Guid OrderId { get; set; }
    public Guid ReservationId { get; set; }
    public SagaState State { get; set; }

    // Steps: ReserveInventory -> PlaceOrder -> ConfirmReservation
    // Compensations: ReleaseReservation -> CancelOrder
}
```

**Choreography Saga** -- each module reacts to events from the previous step and publishes its own event on completion or failure. No central orchestrator exists:

```
OrderRequested (event) -->
  InventoryModule handles it --> InventoryReserved (event) -->
    OrderModule handles it --> OrderPlaced (event) -->
      InventoryModule handles it --> InventoryConfirmed (event)
```

Choose orchestration when the flow is complex and needs to be observable in one place. Choose choreography when the modules are truly independent and you accept higher debugging complexity.

---

## Testing Strategy

### Default: centralized test project

The strongly preferred layout is **one test project for the solution** (e.g., `[Product].Tests`), organized internally by module and concern:

```
[Product].Tests/
  Architecture/           # Boundary enforcement tests (NetArchTest, ArchUnitNET, etc.)
  [Module]/
    Unit/                 # Unit tests for domain logic, services, providers
    Integration/          # Tests requiring a real database, broker, or external service
  Shared/                 # Test helpers, fixtures, base classes
```

This keeps architecture tests in one place, makes cross-module integration scenarios easier to write, and avoids proliferating test projects that have to be maintained separately.

### Exception: per-module test projects

A module may have its own `[Module].Tests` project when:

- The module is **expected to be reused across multiple products** and must be portable with its own test suite
- The module is **highly complex** and its unit tests are numerous enough that isolating them meaningfully reduces cognitive load for contributors working only on that module
- The decision is **explicitly documented** (e.g., in the module's README or an ADR)

Per-module tests are the exception, not the default. Do not create them to avoid adding a test to the central project.

### Architecture boundary tests

Architecture tests should be part of the centralized project and should run on every build. They are not optional. At minimum, assert:

- No module's non-Public assembly has a dependency on another module's non-Public assembly (the cross-module boundary rule)
- `[Module].Infrastructure` does not reference `[Module].Public` or `[Module].Application` (would create a circular dependency)
- `[Module].Domain` does not reference `[Module].Infrastructure`, `[Module].Public`, or `[Module].Application`

### Integration test isolation

Integration tests that hit a real database should:

- Use an isolated schema or test database (not the development database)
- Clean up after themselves (transaction rollback, respawn, or disposable containers)
- Not depend on execution order

---

## Checklist: Adding a New Module

1. Identify the bounded context boundary using event storming, context mapping, or ubiquitous language analysis -- document the rationale (in an ADR or the module README)
2. Determine whether the module warrants all 4 projects or whether Domain can be collapsed into Public (justify and document the decision if collapsing)
3. Create the chosen set of class library projects following the `[Module].[Layer]` naming convention
4. Set up project references per the dependency hierarchy above (each layer may reference any layer below it; no layer may reference a layer above it — that creates a circular dependency)
5. Define domain entities in `[Module].Domain/Objects/` (or in `[Module].Public` if collapsed, with justification)
6. Define DTOs, cross-module interfaces, and any published event definitions in `[Module].Public/`
7. Decide and document the Public interface failure contract (throw vs. Result) before defining interfaces
8. Implement data access in `[Module].Infrastructure/` using the chosen tooling
9. Implement provider interfaces from `.Public` in `[Module].Application/Providers/`
10. Define endpoints/controllers in `[Module].Application/Endpoints/` or `Controllers/`, with request/response types co-located
11. Co-locate input validation with the endpoints it validates (in `Application`)
12. If using background jobs or hosted services, implement them in `[Module].Application/Handlers/` or `/Jobs/` and register them in the DI extension
13. Register a health check for the module's primary dependency (database, broker, etc.) in the DI extension
14. Write DI registration extension methods in `[Module].Application/Extensions/`
15. Register the module in the host application using those extension methods
16. Add the module's database/resources to the orchestration configuration (see Orchestration and Hosting section for tool options)
17. Add the module to architecture enforcement tests in the centralized test project
18. If the module publishes events, document the event catalog in the module README or Public project summary
19. If the module is owned by a distinct team or will be reused across products, create a module README with bounded context rationale, event catalog, and any collapsed layer or CQRS decisions
