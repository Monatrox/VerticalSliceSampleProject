# Template 2: Endpoint-per-Feature — EF Core + FastEndpoints / Minimal API

## When to Choose This Template

Choose this template when:

- Building a new module from scratch where the vertical-slice pattern should be most visible in the code layout
- The team wants one file (or one small folder) per use case, not one controller per aggregate
- EF Core is the ORM of choice (strongly-typed LINQ, migrations, change tracking)
- You want request-scoped validation co-located with the feature it validates
- The module does not require separate read and write models (→ Template 3 for that)

Do **not** choose this template when:
- The team is unfamiliar with FastEndpoints or Minimal API and prefers the familiar MVC controller structure (→ Template 1)
- Read and write workloads diverge significantly (→ Template 3)
- The module is primarily event-driven with async workflows (→ Template 4)

> **Endpoint framework choice:** The skeletons below show FastEndpoints, but the same folder structure works identically with Minimal API `MapGroup` / `MapGet` / `MapPost` handlers. Swap the base class and registration call; everything else stays the same.

---

## Project Structure

```
[Module]/
  [Module].Domain/
    Objects/
      [Entity].cs                    # Core domain entity; domain invariants here
    Enums/
      [StatusEnum].cs
  [Module].Public/
    DTO/
      [Entity]Dto.cs                 # Immutable record; stable cross-module shape
    Abstractions/
      I[Entity]Provider.cs           # Interface for cross-module consumption
  [Module].Infrastructure/
    Persistence/
      [Module]DbContext.cs           # EF Core DbContext; owns schema configuration
      Configuration/
        [Entity]Configuration.cs     # IEntityTypeConfiguration<T>
      Migrations/                    # EF Core migrations
    Repositories/
      [Entity]Repository.cs          # EF Core repository implementation
  [Module].Application/
    Endpoints/
      Get[Entity]/                   # One folder per use case
        Get[Entity]Endpoint.cs
        Get[Entity]Request.cs
        Get[Entity]Response.cs
      Create[Entity]/
        Create[Entity]Endpoint.cs
        Create[Entity]Request.cs
        Create[Entity]Response.cs
      Update[Entity]/
        ...
      Delete[Entity]/
        ...
    Providers/
      [Entity]Provider.cs            # Implements I[Entity]Provider from Public
    Extensions/
      [Module]ServiceExtensions.cs   # DI registration entry point
```

---

## Project References

```
[Module].Domain         --> (nothing inside the module)
[Module].Infrastructure --> [Module].Domain
[Module].Public         --> [Module].Infrastructure, [Module].Domain
[Module].Application    --> [Module].Domain, [Module].Infrastructure, [Module].Public
```

The host application references `[Module].Public` only (plus calls the DI extension from `[Module].Application`).

---

## Key Class Skeletons

### Domain — `[Module].Domain/Objects/Order.cs`

```csharp
// Domain entity. No EF Core attributes required here — use Fluent API in Infrastructure.
// Domain invariants are methods or property setters that guard state.
public class Order
{
    public Guid Id { get; private set; }
    public Guid CustomerId { get; private set; }
    public OrderStatus Status { get; private set; }
    public decimal Total { get; private set; }
    public DateTime CreatedAt { get; private set; }

    // Private constructor for EF Core materialization
    private Order() { }

    // Factory method enforces creation invariants
    public static Order Create(Guid customerId, decimal total)
    {
        if (total <= 0)
            throw new ArgumentOutOfRangeException(nameof(total), "Total must be positive.");

        return new Order
        {
            Id = Guid.NewGuid(),
            CustomerId = customerId,
            Status = OrderStatus.Pending,
            Total = total,
            CreatedAt = DateTime.UtcNow
        };
    }

    public void Cancel()
    {
        if (Status == OrderStatus.Shipped)
            throw new InvalidOperationException("Cannot cancel a shipped order.");
        Status = OrderStatus.Cancelled;
    }
}
```

### Infrastructure — `[Module].Infrastructure/Persistence/OrderDbContext.cs`

```csharp
// Scoped to this module's schema only. The host does not know about this DbContext.
public class OrderDbContext(DbContextOptions<OrderDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Apply all IEntityTypeConfiguration<T> found in this assembly
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OrderDbContext).Assembly);

        // Scope to module-owned schema
        modelBuilder.HasDefaultSchema("orders");
    }
}
```

### Infrastructure — `[Module].Infrastructure/Persistence/Configuration/OrderConfiguration.cs`

```csharp
// Fluent API keeps EF Core concerns out of the domain entity.
public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.HasKey(o => o.Id);
        builder.Property(o => o.Total).HasPrecision(18, 2);
        builder.Property(o => o.Status)
               .HasConversion<string>()   // Store as string; readable in the DB
               .HasMaxLength(50);
        builder.ToTable("Orders");        // Explicit table name; schema from DbContext
    }
}
```

### Infrastructure — `[Module].Infrastructure/Repositories/OrderRepository.cs`

```csharp
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<Order>> GetAllAsync(CancellationToken ct = default);
    Task AddAsync(Order order, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
}

public class OrderRepository(OrderDbContext db) : IOrderRepository
{
    public Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        db.Orders.FirstOrDefaultAsync(o => o.Id == id, ct);

    public async Task<IEnumerable<Order>> GetAllAsync(CancellationToken ct = default) =>
        await db.Orders.AsNoTracking().ToListAsync(ct);

    public async Task AddAsync(Order order, CancellationToken ct = default) =>
        await db.Orders.AddAsync(order, ct);

    public Task SaveChangesAsync(CancellationToken ct = default) =>
        db.SaveChangesAsync(ct);

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var order = await db.Orders.FindAsync([id], ct);
        if (order is null) return false;
        db.Orders.Remove(order);
        await db.SaveChangesAsync(ct);
        return true;
    }
}
```

### Application — Endpoint (FastEndpoints style)

**`[Module].Application/Endpoints/GetOrder/GetOrderRequest.cs`**

```csharp
// Request type: HTTP concern only — lives alongside the endpoint.
public sealed record GetOrderRequest(Guid Id);
```

**`[Module].Application/Endpoints/GetOrder/GetOrderResponse.cs`**

```csharp
// Response type: HTTP concern only — maps from domain entity or DTO.
public sealed record GetOrderResponse(
    Guid Id,
    Guid CustomerId,
    string Status,
    decimal Total,
    DateTime CreatedAt);
```

**`[Module].Application/Endpoints/GetOrder/GetOrderEndpoint.cs`**

```csharp
// Thin: delegate all data access to the repository. No SQL or EF queries here.
// Validator is registered via FastEndpoints' automatic discovery.
public sealed class GetOrderEndpoint(IOrderRepository repository)
    : Endpoint<GetOrderRequest, GetOrderResponse>
{
    public override void Configure()
    {
        Get("/api/orders/{Id}");
        AllowAnonymous(); // Or: Roles("..."); Policies("...");
    }

    public override async Task HandleAsync(GetOrderRequest req, CancellationToken ct)
    {
        var order = await repository.GetByIdAsync(req.Id, ct);
        if (order is null)
        {
            await SendNotFoundAsync(ct);
            return;
        }

        await SendOkAsync(new GetOrderResponse(
            order.Id, order.CustomerId,
            order.Status.ToString(), order.Total, order.CreatedAt), ct);
    }
}
```

**`[Module].Application/Endpoints/CreateOrder/CreateOrderRequest.cs`**

```csharp
public sealed record CreateOrderRequest(Guid CustomerId, decimal Total);
```

**`[Module].Application/Endpoints/CreateOrder/CreateOrderEndpoint.cs`**

```csharp
// Validator (FluentValidation via FastEndpoints) lives in the same folder.
public sealed class CreateOrderEndpoint(IOrderRepository repository)
    : Endpoint<CreateOrderRequest, CreateOrderResponse>
{
    public override void Configure()
    {
        Post("/api/orders");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateOrderRequest req, CancellationToken ct)
    {
        // Factory method on domain entity enforces creation invariants
        var order = Order.Create(req.CustomerId, req.Total);
        await repository.AddAsync(order, ct);
        await repository.SaveChangesAsync(ct);

        await SendCreatedAtAsync<GetOrderEndpoint>(
            new { Id = order.Id },
            new CreateOrderResponse(order.Id),
            generateAbsoluteUrl: true,
            cancellation: ct);
    }
}

// Validator: co-located with the endpoint in the same folder
public sealed class CreateOrderValidator : Validator<CreateOrderRequest>
{
    public CreateOrderValidator()
    {
        RuleFor(r => r.CustomerId).NotEmpty();
        RuleFor(r => r.Total).GreaterThan(0);
    }
}
```

### Application — `[Module].Application/Providers/OrderProvider.cs`

```csharp
// Implements the cross-module interface from [Module].Public.
public sealed class OrderProvider(IOrderRepository repository) : IOrderProvider
{
    public async ValueTask<IReadOnlyList<OrderDto>> GetAllAsync(CancellationToken ct = default)
    {
        var orders = await repository.GetAllAsync(ct);
        return orders.Select(ToDto).ToList();
    }

    public async ValueTask<OrderDto?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        var order = await repository.GetByIdAsync(id, ct);
        return order is null ? null : ToDto(order);
    }

    private static OrderDto ToDto(Order o) =>
        new(o.Id, o.CustomerId, o.Status.ToString(), o.Total, o.CreatedAt);
}
```

### Application — `[Module].Application/Extensions/OrderServiceExtensions.cs`

```csharp
public static class OrderServiceExtensions
{
    public static IServiceCollection AddOrderModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var options = configuration
            .GetSection("OrderModule")
            .Get<OrderModuleOptions>() ?? new OrderModuleOptions();
        services.AddSingleton(options);

        // EF Core — scoped to this module's DbContext only
        services.AddDbContext<OrderDbContext>(opt =>
            opt.UseSqlServer(options.ConnectionString));

        // Repositories and public provider
        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<IOrderProvider, OrderProvider>();

        // Health check
        services.AddHealthChecks()
            .AddDbContextCheck<OrderDbContext>("orders-db");

        return services;
    }
}
```

**In the host `Program.cs`:**

```csharp
// Register the module
builder.Services.AddOrderModule(builder.Configuration);

// FastEndpoints discovers all endpoints in all referenced assemblies
app.UseFastEndpoints();
```

---

## Migration Notes

**From N-tier monolith:** The biggest shift is replacing one controller-per-aggregate with one folder-per-use-case. During migration, start by lifting the existing service logic into endpoint handlers as-is, then refactor toward the domain entity pattern (factory methods, private setters, invariants on the entity) as the module stabilizes.

**From Big Ball of Mud:** EF Core's `AsNoTracking()` on reads and explicit `SaveChangesAsync()` calls make it easier to see where database mutations happen. Use this visibility to identify and eliminate implicit state mutations that are common in Big Ball of Mud codebases.

**From microservices consolidation:** If the incoming service already used EF Core, reuse its `DbContext` and migrations in `[Module].Infrastructure/Persistence/`. Rename the schema to match the module's bounded context (use EF Core migrations to perform the rename) and wrap it in the 4-layer structure.

---

## Common Mistakes to Avoid

- Putting `DbContext` in `Application` or `Public` — it belongs in `Infrastructure`
- Calling `db.SaveChangesAsync()` from inside a repository method on every individual operation when multiple writes should be atomic — consider a unit-of-work scope managed at the endpoint level
- Placing validators in a separate `Validators/` folder away from the endpoint — co-location is the point of this template
- Leaking EF Core navigation properties or `IQueryable` through the Public interface — always map to DTOs before the Public boundary
- Forgetting `AsNoTracking()` on read-only queries — it has a meaningful performance impact under EF Core
- Sharing a single `DbContext` type across modules — each module must own its own `DbContext`
