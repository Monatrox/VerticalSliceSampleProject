# Template 4: Event-Driven / Async — EF Core + Outbox + Minimal API

## When to Choose This Template

Choose this template when:

- The module needs to **publish integration events** that other modules or external systems react to (e.g., `OrderPlaced`, `InventoryReserved`)
- Operations in the module trigger **async workflows** that should not block the HTTP response
- You need **at-least-once delivery** guarantees — the event must survive a process crash between the state change and the message broker acknowledgment
- The module participates in a **Saga** as an event publisher or event consumer

Do **not** choose this template when:
- The module does not publish events and only reads from a broker — a simpler subscription setup (background job in Application) is sufficient without the full outbox
- All cross-module communication is synchronous (→ Template 1, 2, or 3)
- The module is simple CRUD with no async downstream effects (→ Template 1 or 2)

> **Domain events vs. integration events.** Domain events are internal to the module — they travel only within the same process and the same transaction. Integration events are the public contract published to the broker; they live in `[Module].Public/Events/` and cross the module boundary. This template uses both: domain events trigger the creation of an outbox entry, which is forwarded as an integration event by a background job.

---

## Project Structure

```
[Module]/
  [Module].Domain/
    Objects/
      [Entity].cs                        # Aggregate root; raises domain events
    Events/
      [Entity][Action]DomainEvent.cs     # Internal domain event; not shared
  [Module].Public/
    DTO/
      [Entity]Dto.cs
    Events/
      [Entity][Action]IntegrationEvent.cs  # Cross-module contract; lives in Public
    Abstractions/
      I[Entity]Provider.cs
  [Module].Infrastructure/
    Persistence/
      [Module]DbContext.cs               # Single EF Core DbContext for this template
      Configuration/
        [Entity]Configuration.cs
        OutboxMessageConfiguration.cs
      Migrations/
    Repositories/
      [Entity]Repository.cs
    Outbox/
      OutboxMessage.cs                   # Outbox table row model
      OutboxPublisher.cs                 # Writes domain events → outbox rows (same tx)
    Consumers/
      [Entity][Action]IntegrationEventConsumer.cs  # Subscribes to other modules' events
      Idempotency/
        ConsumedMessageRecord.cs         # Idempotency table row model
  [Module].Application/
    Endpoints/
      Commands/
        Create[Entity]/
          Create[Entity]Endpoint.cs
          Create[Entity]Request.cs
          Create[Entity]Response.cs
      Queries/
        Get[Entity]/
          Get[Entity]Endpoint.cs
    Jobs/
      OutboxRelayJob.cs                  # Background job: outbox → broker
    Providers/
      [Entity]Provider.cs
    Extensions/
      [Module]ServiceExtensions.cs
```

---

## Project References

```
[Module].Domain         --> (nothing inside the module)
[Module].Infrastructure --> [Module].Domain
[Module].Public         --> [Module].Infrastructure, [Module].Domain
[Module].Application    --> [Module].Domain, [Module].Infrastructure, [Module].Public
```

---

## Key Class Skeletons

### Domain — `[Module].Domain/Objects/Order.cs`

```csharp
// Aggregate root. Raises internal domain events that are captured
// by the Infrastructure layer to write outbox entries — all in the same transaction.
public class Order
{
    public Guid Id { get; private set; }
    public Guid CustomerId { get; private set; }
    public OrderStatus Status { get; private set; }
    public decimal Total { get; private set; }
    public DateTime CreatedAt { get; private set; }

    // Domain events collected in-memory; cleared after outbox entries are written.
    private readonly List<object> _domainEvents = [];
    public IReadOnlyList<object> DomainEvents => _domainEvents.AsReadOnly();
    public void ClearDomainEvents() => _domainEvents.Clear();

    private Order() { } // EF Core

    public static Order Create(Guid customerId, decimal total)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(total);
        var order = new Order
        {
            Id = Guid.NewGuid(),
            CustomerId = customerId,
            Status = OrderStatus.Pending,
            Total = total,
            CreatedAt = DateTime.UtcNow
        };
        // Raise a domain event — Infrastructure will translate this into an outbox entry.
        order._domainEvents.Add(new OrderCreatedDomainEvent(order.Id, order.CustomerId, order.Total));
        return order;
    }

    public void Ship()
    {
        if (Status != OrderStatus.Pending)
            throw new InvalidOperationException($"Cannot ship order in status '{Status}'.");
        Status = OrderStatus.Shipped;
        _domainEvents.Add(new OrderShippedDomainEvent(Id));
    }
}
```

### Domain — `[Module].Domain/Events/OrderCreatedDomainEvent.cs`

```csharp
// Internal domain event. Never exposed outside this module.
// Carries the minimum information the outbox publisher needs to build the integration event.
public sealed record OrderCreatedDomainEvent(Guid OrderId, Guid CustomerId, decimal Total);
public sealed record OrderShippedDomainEvent(Guid OrderId);
```

### Public — `[Module].Public/Events/OrderPlacedIntegrationEvent.cs`

```csharp
// Cross-module integration event contract. Versioned via namespace if a breaking change occurs.
// Consumers in other modules reference this type from [Module].Public.
// Keep this type stable — it is a public API contract.
namespace Orders.Public.Events;

public sealed record OrderPlacedIntegrationEvent(
    Guid OrderId,
    Guid CustomerId,
    decimal Total,
    DateTime PlacedAt);
```

### Infrastructure — `[Module].Infrastructure/Outbox/OutboxMessage.cs`

```csharp
// Persisted in the same database transaction as the business data.
// Guarantees the event is never lost even if the process crashes before broker delivery.
public sealed class OutboxMessage
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public string EventType { get; init; } = default!;  // Fully-qualified type name
    public string Payload { get; init; } = default!;    // JSON-serialized integration event
    public DateTime CreatedAt { get; init; } = DateTime.UtcNow;
    public DateTime? ProcessedAt { get; private set; }

    public void MarkProcessed() => ProcessedAt = DateTime.UtcNow;
}
```

### Infrastructure — `[Module].Infrastructure/Outbox/OutboxPublisher.cs`

```csharp
// Called by the repository's SaveChangesAsync override (or directly from Application).
// Translates domain events → outbox rows within the same EF Core transaction.
// Mapping from domain event to integration event happens here — a module-internal decision.
public sealed class OutboxPublisher(OrderDbContext db)
{
    public void PublishDomainEvents(IEnumerable<Order> aggregates)
    {
        foreach (var aggregate in aggregates)
        {
            foreach (var domainEvent in aggregate.DomainEvents)
            {
                var integrationEvent = MapToIntegrationEvent(domainEvent);
                if (integrationEvent is null) continue;

                db.OutboxMessages.Add(new OutboxMessage
                {
                    EventType = integrationEvent.GetType().AssemblyQualifiedName!,
                    Payload = JsonSerializer.Serialize(integrationEvent, integrationEvent.GetType())
                });
            }
            aggregate.ClearDomainEvents();
        }
    }

    private static object? MapToIntegrationEvent(object domainEvent) => domainEvent switch
    {
        OrderCreatedDomainEvent e => new OrderPlacedIntegrationEvent(
            e.OrderId, e.CustomerId, e.Total, DateTime.UtcNow),
        OrderShippedDomainEvent e => new OrderShippedIntegrationEvent(e.OrderId, DateTime.UtcNow),
        _ => null  // Domain events without a corresponding integration event are silently skipped
    };
}
```

### Infrastructure — `[Module].Infrastructure/Persistence/OrderDbContext.cs`

```csharp
// Single DbContext for this template (write-only; no separate read DbContext).
// Overrides SaveChangesAsync to publish domain events to the outbox before committing.
public class OrderDbContext(DbContextOptions<OrderDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OutboxMessage> OutboxMessages => Set<OutboxMessage>();
    public DbSet<ConsumedMessageRecord> ConsumedMessages => Set<ConsumedMessageRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OrderDbContext).Assembly);
        modelBuilder.HasDefaultSchema("orders");
    }

    public override async Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        // Collect domain events from all tracked aggregates before saving.
        var aggregatesWithEvents = ChangeTracker
            .Entries<Order>()
            .Where(e => e.Entity.DomainEvents.Count > 0)
            .Select(e => e.Entity)
            .ToList();

        // Write outbox rows in the same transaction as the business data change.
        var publisher = new OutboxPublisher(this);
        publisher.PublishDomainEvents(aggregatesWithEvents);

        return await base.SaveChangesAsync(ct);
    }
}
```

### Infrastructure — `[Module].Infrastructure/Consumers/Idempotency/ConsumedMessageRecord.cs`

```csharp
// Persisted in the same DB transaction as the consumer's side-effect.
// Prevents the same integration event from being processed more than once
// even when the broker delivers it multiple times (at-least-once semantics).
public sealed class ConsumedMessageRecord
{
    public Guid MessageId { get; init; }     // The event's unique ID (idempotency key)
    public string ConsumerName { get; init; } = default!;
    public DateTime ProcessedAt { get; init; } = DateTime.UtcNow;
}
```

### Infrastructure — `[Module].Infrastructure/Consumers/InventoryReservedIntegrationEventConsumer.cs`

```csharp
// Subscribes to an integration event published by another module.
// Uses idempotency: checks ConsumedMessageRecord before acting; writes it in the same transaction.
// The broker-specific subscription (MassTransit, NServiceBus, etc.) is registered in ServiceExtensions.
public sealed class InventoryReservedIntegrationEventConsumer(
    IOrderRepository repository,
    OrderDbContext db,
    ILogger<InventoryReservedIntegrationEventConsumer> logger)
{
    public async Task ConsumeAsync(
        InventoryReservedIntegrationEvent integrationEvent,
        CancellationToken ct = default)
    {
        // Idempotency check: skip if already processed.
        var alreadyProcessed = await db.ConsumedMessages
            .AnyAsync(r => r.MessageId == integrationEvent.MessageId
                        && r.ConsumerName == nameof(InventoryReservedIntegrationEventConsumer), ct);
        if (alreadyProcessed)
        {
            logger.LogInformation("Skipping duplicate message {MessageId}", integrationEvent.MessageId);
            return;
        }

        var order = await repository.GetByIdAsync(integrationEvent.OrderId, ct);
        if (order is null)
        {
            logger.LogWarning("Order {OrderId} not found for InventoryReserved event", integrationEvent.OrderId);
            return;
        }

        order.ConfirmInventory();
        await repository.SaveChangesAsync(ct);

        // Record consumption in the same transaction as the state change.
        db.ConsumedMessages.Add(new ConsumedMessageRecord
        {
            MessageId = integrationEvent.MessageId,
            ConsumerName = nameof(InventoryReservedIntegrationEventConsumer)
        });
        await db.SaveChangesAsync(ct);
    }
}
```

### Application — `[Module].Application/Endpoints/Commands/CreateOrder/CreateOrderEndpoint.cs`

```csharp
// Command endpoint: creates the aggregate, which raises a domain event.
// The domain event is translated to an outbox entry by OrderDbContext.SaveChangesAsync.
// No direct broker call here — delivery is the relay job's responsibility.
app.MapPost("/api/orders", async (
    CreateOrderRequest req,
    IOrderRepository repository,
    CancellationToken ct) =>
{
    var order = Order.Create(req.CustomerId, req.Total);
    await repository.AddAsync(order, ct);
    await repository.SaveChangesAsync(ct);  // Outbox entry written atomically here

    return Results.CreatedAtRoute("GetOrder", new { Id = order.Id }, new CreateOrderResponse(order.Id));
})
.WithName("CreateOrder")
.WithOpenApi();

public sealed record CreateOrderRequest(Guid CustomerId, decimal Total);
public sealed record CreateOrderResponse(Guid Id);
```

### Application — `[Module].Application/Jobs/OutboxRelayJob.cs`

```csharp
// Hosted service (or Hangfire/Quartz job) that polls the outbox table
// and forwards unprocessed entries to the message broker.
// Runs in Application — it orchestrates Infrastructure (outbox table) and the broker client.
// If the broker publish fails, the row is left unprocessed and retried on the next poll.
public sealed class OutboxRelayJob(
    IServiceScopeFactory scopeFactory,
    IMessageBroker broker,                  // broker client abstraction; registered in DI
    ILogger<OutboxRelayJob> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await ProcessBatchAsync(stoppingToken);
            await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
        }
    }

    private async Task ProcessBatchAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();

        var pending = await db.OutboxMessages
            .Where(m => m.ProcessedAt == null)
            .OrderBy(m => m.CreatedAt)
            .Take(50)
            .ToListAsync(ct);

        foreach (var message in pending)
        {
            try
            {
                var eventType = Type.GetType(message.EventType);
                if (eventType is null) continue;

                var payload = JsonSerializer.Deserialize(message.Payload, eventType);
                if (payload is null) continue;

                await broker.PublishAsync(payload, eventType, ct);
                message.MarkProcessed();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Failed to relay outbox message {MessageId}", message.Id);
                // Leave ProcessedAt null — will be retried on next poll.
            }
        }

        await db.SaveChangesAsync(ct);
    }
}
```

### Application — `[Module].Application/Extensions/OrderServiceExtensions.cs`

```csharp
public static class OrderServiceExtensions
{
    public static IServiceCollection AddOrderModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var options = configuration
            .GetSection("OrderModule")
            .Get<OrderModuleOptions>() ?? new OrderModuleOptions();
        services.AddSingleton(options);

        // EF Core
        services.AddDbContext<OrderDbContext>(opt =>
            opt.UseSqlServer(options.ConnectionString));

        // Repository
        services.AddScoped<IOrderRepository, OrderRepository>();

        // Public provider
        services.AddScoped<IOrderProvider, OrderProvider>();

        // Outbox relay job (BackgroundService)
        services.AddHostedService<OutboxRelayJob>();

        // Message broker consumer registrations (broker-specific — example shows MassTransit)
        // services.AddMassTransit(cfg => { cfg.AddConsumer<InventoryReservedIntegrationEventConsumer>(); ... });

        // Health checks
        services.AddHealthChecks()
            .AddDbContextCheck<OrderDbContext>("orders-db");

        return services;
    }
}
```

---

## Dead-Letter Queue

When the `OutboxRelayJob` fails repeatedly for a given message (e.g., the event type is no longer recognized, or the payload is malformed), the row will remain unprocessed indefinitely and block any ordering guarantees for subsequent messages. Two strategies:

- **Max-attempt counter on `OutboxMessage`:** Add a `RetryCount` column; after N failures, move the row to a `DeadLetterOutboxMessages` table and alert. Processing continues for other rows.
- **Broker-native DLQ:** If the broker client is configured with a dead-letter queue, failed deliveries land there automatically. The outbox row can be marked `ProcessedAt` when the broker acknowledges receipt (not when downstream consumers process it).

Choose the approach that matches your broker's delivery semantics and your observability requirements.

---

## Message Ordering

If consumers of your integration events require ordered processing (e.g., `OrderPlaced` must always be processed before `OrderShipped` for the same order), apply the **Sequential Convoy** pattern:

- Partition the outbox relay by a key (e.g., `OrderId`) so messages for the same entity are forwarded in creation order
- Configure the broker's consumer group to route messages with the same partition key to the same consumer instance
- Do not rely on wall-clock timestamps for ordering — use the `OutboxMessage.CreatedAt` column and process within a partition strictly in ascending order

This is a constraint on the relay job and broker configuration, not on the domain model.

---

## Migration Notes

**From N-tier monolith:** The most common starting point is a service method that both saves to the database and calls `EmailService.Send(...)` or fires a synchronous event directly. Replace the synchronous side-effect with an outbox entry. The domain event pattern is new discipline here — introduce it incrementally: start with `OrderDbContext.SaveChangesAsync` writing outbox rows for a single event type before rolling it out across all aggregates.

**From Big Ball of Mud:** Look for fire-and-forget calls scattered through service methods (`_ = Task.Run(...)`, `EventBus.Publish(...)` without awaiting). These are candidates for the outbox. Identify each async side-effect, wrap it in an integration event, and replace the ad-hoc call with an outbox entry. The idempotency table protects against duplicate processing that often already exists in Big Ball codebases.

**From microservices consolidation:** If the incoming service already published to a broker (e.g., via MassTransit or NServiceBus), the broker registration moves to `ServiceExtensions`. The outbox pattern may or may not have been in place — if it was not, add it now. Consumer registration moves to `Infrastructure/Consumers/`. The idempotency record pattern should be retained even if the microservice did not use it — at-least-once delivery within a modular monolith still requires it.

---

## Common Mistakes to Avoid

- **Writing to the broker directly from the command endpoint** — if the process crashes after the broker call but before `SaveChangesAsync`, the event is sent but the state change is lost (or vice versa). Always use the outbox.
- **Raising domain events after `SaveChangesAsync`** — domain events must be raised before saving so that the `OrderDbContext` override can capture them in the same transaction.
- **Sharing the `OutboxMessage` or `ConsumedMessageRecord` types across modules** — each module has its own outbox table in its own schema. These are infrastructure implementation details, not shared contracts.
- **Exposing `OrderCreatedDomainEvent` in `[Module].Public`** — domain events are internal. Only integration events (in `Public/Events/`) cross the module boundary.
- **Skipping idempotency in consumers** — at-least-once delivery means your consumer will see duplicates. The `ConsumedMessageRecord` pattern protects against this; omitting it causes duplicate side effects that are hard to diagnose.
- **Blocking the relay job on a single failing message** — if one outbox row fails repeatedly, it must not prevent other rows from being forwarded. Use a max-retry counter or skip-and-DLQ strategy.
- **Registering `OrderDbContext` as Singleton** — the `DbContext` must be Scoped. `OutboxRelayJob` uses `IServiceScopeFactory` deliberately to create a new scope per batch, not to reuse a shared context across iterations.
