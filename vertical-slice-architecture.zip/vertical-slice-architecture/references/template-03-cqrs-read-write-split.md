# Template 3: CQRS with Read/Write Split — EF Core (writes) + Dapper (reads)

## When to Choose This Template

Choose this template when:

- Read and write workloads have meaningfully different performance profiles (reads are frequent aggregations; writes are strict domain-rule-enforcing operations)
- The module's query patterns are complex enough that using the write-side domain model for reads is awkward or slow
- The team wants the CQRS discipline to explicitly separate query logic from command logic
- You need the ability to scale reads independently of writes, or to add read replicas without changing write-side code

Do **not** choose this template when:
- The module has simple, symmetrical CRUD (reads look the same as writes) — overhead is not justified (→ Template 1 or 2)
- The team is unfamiliar with CQRS; the pattern adds reasoning overhead and should be a deliberate choice
- The module is primarily event-driven (→ Template 4)

> **CQRS is a module-internal concern.** Other modules still interact with this module only through its `.Public` interfaces. The CQRS split is invisible to consumers.

---

## Project Structure

```
[Module]/
  [Module].Domain/
    Objects/
      [Entity].cs                    # Aggregate root; domain invariants here
    Enums/
      [StatusEnum].cs
  [Module].Public/
    DTO/
      [Entity]Dto.cs                 # Read-side projection; stable cross-module shape
    Abstractions/
      I[Entity]Provider.cs           # Interface for cross-module consumption
  [Module].Infrastructure/
    Persistence/
      WriteDb/
        [Module]WriteDbContext.cs    # EF Core DbContext for writes only
        Configuration/
          [Entity]Configuration.cs
        Migrations/
      ReadDb/
        [Entity]ReadModel.cs         # Lightweight POCO for Dapper query results
        [Entity]QueryService.cs      # Dapper-based read service
    Repositories/
      [Entity]Repository.cs          # EF Core write-side repository
  [Module].Application/
    Endpoints/
      Commands/
        Create[Entity]/
          Create[Entity]Endpoint.cs
          Create[Entity]Request.cs
          Create[Entity]Response.cs
        Update[Entity]/
          ...
        Delete[Entity]/
          ...
      Queries/
        Get[Entity]/
          Get[Entity]Endpoint.cs
          Get[Entity]Request.cs
        List[Entity]/
          List[Entity]Endpoint.cs
          List[Entity]Request.cs
    Providers/
      [Entity]Provider.cs
    Extensions/
      [Module]ServiceExtensions.cs
```

---

## Project References

```
[Module].Domain         --> (nothing inside the module)
[Module].Infrastructure --> [Module].Domain
[Module].Public         --> [Module].Infrastructure, [Module].Domain
[Module].Application    --> [Module].Domain, [Module].Infrastructure, [Module].Public
```

---

## Key Class Skeletons

### Domain — `[Module].Domain/Objects/Order.cs`

```csharp
// Write-side aggregate root. Used exclusively by command handlers.
// Enforces invariants; never used directly in read queries.
public class Order
{
    public Guid Id { get; private set; }
    public Guid CustomerId { get; private set; }
    public OrderStatus Status { get; private set; }
    public decimal Total { get; private set; }
    public DateTime CreatedAt { get; private set; }

    private Order() { } // EF Core

    public static Order Create(Guid customerId, decimal total)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(total);
        return new Order
        {
            Id = Guid.NewGuid(),
            CustomerId = customerId,
            Status = OrderStatus.Pending,
            Total = total,
            CreatedAt = DateTime.UtcNow
        };
    }

    public void Ship()
    {
        if (Status != OrderStatus.Pending)
            throw new InvalidOperationException($"Cannot ship order in status '{Status}'.");
        Status = OrderStatus.Shipped;
    }
}
```

### Infrastructure — Write Side

**`[Module].Infrastructure/Persistence/WriteDb/OrderWriteDbContext.cs`**

```csharp
// Handles writes only: change tracking, migrations, aggregate persistence.
public class OrderWriteDbContext(DbContextOptions<OrderWriteDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OrderWriteDbContext).Assembly);
        modelBuilder.HasDefaultSchema("orders");
    }
}
```

**`[Module].Infrastructure/Repositories/OrderRepository.cs`**

```csharp
// Write-side repository: works with the domain aggregate through EF Core.
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Order order, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
}

public class OrderRepository(OrderWriteDbContext db) : IOrderRepository
{
    public Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        db.Orders.FirstOrDefaultAsync(o => o.Id == id, ct);

    public async Task AddAsync(Order order, CancellationToken ct = default) =>
        await db.Orders.AddAsync(order, ct);

    public Task SaveChangesAsync(CancellationToken ct = default) =>
        db.SaveChangesAsync(ct);

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var order = await db.Orders.FindAsync([id], ct);
        if (order is null) return false;
        db.Orders.Remove(order);
        await db.SaveChangesAsync(ct);
        return true;
    }
}
```

### Infrastructure — Read Side

**`[Module].Infrastructure/Persistence/ReadDb/OrderReadModel.cs`**

```csharp
// Lightweight POCO for Dapper. Not a domain entity — just a projection.
// Property names match the column names returned by the read query.
public sealed record OrderReadModel(
    Guid Id,
    Guid CustomerId,
    string Status,
    decimal Total,
    DateTime CreatedAt);
```

**`[Module].Infrastructure/Persistence/ReadDb/OrderQueryService.cs`**

```csharp
// Read-only Dapper service. No domain entity, no change tracking.
// SQL reflects the actual read requirement — not forced through the write model.
public interface IOrderQueryService
{
    Task<OrderReadModel?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<OrderReadModel>> GetAllAsync(CancellationToken ct = default);
    Task<IEnumerable<OrderReadModel>> GetByCustomerAsync(Guid customerId, CancellationToken ct = default);
}

public class OrderQueryService(IDbConnection db) : IOrderQueryService
{
    public async Task<OrderReadModel?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        const string sql = "SELECT Id, CustomerId, Status, Total, CreatedAt FROM orders.Orders WHERE Id = @Id";
        return await db.QuerySingleOrDefaultAsync<OrderReadModel>(sql, new { Id = id });
    }

    public async Task<IEnumerable<OrderReadModel>> GetAllAsync(CancellationToken ct = default)
    {
        const string sql = "SELECT Id, CustomerId, Status, Total, CreatedAt FROM orders.Orders";
        return await db.QueryAsync<OrderReadModel>(sql);
    }

    public async Task<IEnumerable<OrderReadModel>> GetByCustomerAsync(Guid customerId, CancellationToken ct = default)
    {
        // Read-optimized query: might JOIN summary tables or read replicas.
        // The write-side model does not need to support this query pattern at all.
        const string sql = @"
            SELECT o.Id, o.CustomerId, o.Status, o.Total, o.CreatedAt
            FROM orders.Orders o
            WHERE o.CustomerId = @CustomerId
            ORDER BY o.CreatedAt DESC";
        return await db.QueryAsync<OrderReadModel>(sql, new { CustomerId = customerId });
    }
}
```

### Application — Command Endpoint

**`[Module].Application/Endpoints/Commands/CreateOrder/CreateOrderEndpoint.cs`**

```csharp
// Command endpoint: uses the write-side repository and domain aggregate.
// Validator is co-located in the same folder.
public sealed class CreateOrderEndpoint(IOrderRepository repository)
    : Endpoint<CreateOrderRequest, CreateOrderResponse>
{
    public override void Configure()
    {
        Post("/api/orders");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateOrderRequest req, CancellationToken ct)
    {
        var order = Order.Create(req.CustomerId, req.Total);
        await repository.AddAsync(order, ct);
        await repository.SaveChangesAsync(ct);

        await SendCreatedAtAsync<GetOrderEndpoint>(
            new { Id = order.Id },
            new CreateOrderResponse(order.Id),
            generateAbsoluteUrl: true,
            cancellation: ct);
    }
}

public sealed record CreateOrderRequest(Guid CustomerId, decimal Total);
public sealed record CreateOrderResponse(Guid Id);

public sealed class CreateOrderValidator : Validator<CreateOrderRequest>
{
    public CreateOrderValidator()
    {
        RuleFor(r => r.CustomerId).NotEmpty();
        RuleFor(r => r.Total).GreaterThan(0);
    }
}
```

### Application — Query Endpoint

**`[Module].Application/Endpoints/Queries/GetOrder/GetOrderEndpoint.cs`**

```csharp
// Query endpoint: uses the read-side query service, NOT the write-side repository.
// No domain aggregate is loaded; no change tracking; returns the projection directly.
public sealed class GetOrderEndpoint(IOrderQueryService queries)
    : Endpoint<GetOrderRequest, GetOrderResponse>
{
    public override void Configure()
    {
        Get("/api/orders/{Id}");
        AllowAnonymous();
    }

    public override async Task HandleAsync(GetOrderRequest req, CancellationToken ct)
    {
        var order = await queries.GetByIdAsync(req.Id, ct);
        if (order is null)
        {
            await SendNotFoundAsync(ct);
            return;
        }

        await SendOkAsync(new GetOrderResponse(
            order.Id, order.CustomerId, order.Status, order.Total, order.CreatedAt), ct);
    }
}

public sealed record GetOrderRequest(Guid Id);
public sealed record GetOrderResponse(
    Guid Id, Guid CustomerId, string Status, decimal Total, DateTime CreatedAt);
```

### Application — `[Module].Application/Providers/OrderProvider.cs`

```csharp
// Cross-module provider uses the read-side query service — fast, no ORM overhead.
public sealed class OrderProvider(IOrderQueryService queries) : IOrderProvider
{
    public async ValueTask<IReadOnlyList<OrderDto>> GetAllAsync(CancellationToken ct = default)
    {
        var orders = await queries.GetAllAsync(ct);
        return orders.Select(ToDto).ToList();
    }

    public async ValueTask<OrderDto?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        var order = await queries.GetByIdAsync(id, ct);
        return order is null ? null : ToDto(order);
    }

    private static OrderDto ToDto(OrderReadModel o) =>
        new(o.Id, o.CustomerId, o.Status, o.Total, o.CreatedAt);
}
```

### Application — `[Module].Application/Extensions/OrderServiceExtensions.cs`

```csharp
public static class OrderServiceExtensions
{
    public static IServiceCollection AddOrderModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var options = configuration
            .GetSection("OrderModule")
            .Get<OrderModuleOptions>() ?? new OrderModuleOptions();
        services.AddSingleton(options);

        // Write side: EF Core
        services.AddDbContext<OrderWriteDbContext>(opt =>
            opt.UseSqlServer(options.ConnectionString));
        services.AddScoped<IOrderRepository, OrderRepository>();

        // Read side: Dapper connection (Scoped — never Singleton)
        services.AddScoped<IDbConnection>(_ =>
            new SqlConnection(options.ReadConnectionString ?? options.ConnectionString));
        services.AddScoped<IOrderQueryService, OrderQueryService>();

        // Public provider
        services.AddScoped<IOrderProvider, OrderProvider>();

        // Health check
        services.AddHealthChecks()
            .AddDbContextCheck<OrderWriteDbContext>("orders-write-db")
            .AddSqlServer(options.ReadConnectionString ?? options.ConnectionString, name: "orders-read-db");

        return services;
    }
}
```

---

## When to Add a Materialized View

If reads become expensive (joining many tables, aggregating large datasets), introduce a **Materialized View** table that is refreshed asynchronously:

- Add a `OrderSummary` projection table in the `orders` schema
- Refresh it via a domain event handler or a background job in `[Module].Application/Handlers/`
- Point `IOrderQueryService` read queries at the projection table instead of the base table

This is a module-internal change — the Public interface and DTOs do not change.

---

## Migration Notes

**From N-tier monolith:** The write side maps directly from the existing service + repository layer. The read side replaces ad-hoc queries scattered through service methods with a dedicated query service. Extract the read queries first (they are lower-risk than writes), then refactor the write path to enforce domain invariants.

**From Big Ball of Mud:** CQRS imposes explicit discipline on read vs. write paths — this is especially useful when the Big Ball has a mix of reads and writes in the same methods. Use the split to untangle them: anything that doesn't change state belongs in the read side; anything that does belongs in the write side.

**From microservices consolidation:** If the incoming service already distinguished commands and queries (e.g., via MediatR handlers), this template maps naturally. Lift `IRequestHandler<TCommand>` logic into command endpoints and `IRequestHandler<TQuery>` logic into `IOrderQueryService` methods.

---

## Common Mistakes to Avoid

- Using the write-side `IOrderRepository` from a query endpoint — always use `IOrderQueryService` for reads
- Letting `OrderWriteDbContext` appear in read paths — it enables change tracking and schema configuration that are unnecessary for reads
- Registering `IDbConnection` as Singleton — connections must be Scoped or transient
- Projecting through the domain entity on the read path (loading EF entities and then mapping) — defeats the purpose of the read side
- Letting `OrderReadModel` leak into the Public layer — DTOs in Public are the external contract; read models are internal read-side implementation details
- Skipping the Materialized View consideration when query complexity grows — revisit when read queries begin to span more than 2-3 tables
