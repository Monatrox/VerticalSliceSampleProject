# Template 1: Simple CRUD — MVC Controllers + Dapper

## When to Choose This Template

Choose this template when:

- The module is small with straightforward data access (reads and writes follow the same model)
- The team is migrating from a traditional N-tier monolith and wants a landing zone that is familiar before adopting more complex patterns
- The module has no meaningful divergence between read and write workloads
- Time-to-working-code matters more than long-term read scalability
- The team already has Dapper expertise and wants to leverage parameterized SQL directly

Do **not** choose this template when:
- Read and write workloads have meaningfully different shapes or performance needs (→ Template 3)
- The module publishes events to other modules (→ Template 4)
- The team is building greenfield and wants the most idiomatic vertical-slice experience (→ Template 2)

---

## Project Structure

```
[Module]/
  [Module].Domain/
    Objects/
      [Entity].cs                  # Core domain entity
    Enums/
      [StatusEnum].cs
  [Module].Public/
    DTO/
      [Entity]Dto.cs               # Immutable record; what other modules see
    Abstractions/
      I[Entity]Provider.cs         # Interface for cross-module consumption
  [Module].Infrastructure/
    Persistence/
      [Module]DbContext.cs         # Optional: thin wrapper for connection factory
      Schema/
        [Module]Schema.sql         # Or migration files if using DbUp/Flyway
    Repositories/
      [Entity]Repository.cs        # Dapper-based implementation
  [Module].Application/
    Controllers/
      [Entity]Controller.cs        # MVC controller; one per aggregate root
    Providers/
      [Entity]Provider.cs          # Implements I[Entity]Provider from Public
    Extensions/
      [Module]ServiceExtensions.cs # DI registration entry point
```

---

## Project References

```
[Module].Domain         --> (nothing inside the module)
[Module].Infrastructure --> [Module].Domain
[Module].Public         --> [Module].Infrastructure, [Module].Domain
[Module].Application    --> [Module].Domain, [Module].Infrastructure, [Module].Public
```

The host application references `[Module].Public` only (plus calls the DI extension from `[Module].Application`).

---

## Key Class Skeletons

### Domain — `[Module].Domain/Objects/[Entity].cs`

```csharp
// The entity represents the ubiquitous language of this bounded context.
// No ORM annotations, no HTTP types, no framework imports.
public class Order
{
    public Guid Id { get; set; }
    public Guid CustomerId { get; set; }
    public OrderStatus Status { get; set; }
    public decimal Total { get; set; }
    public DateTime CreatedAt { get; set; }

    // Domain invariant example: enforce rules here, not in the controller
    public void Cancel()
    {
        if (Status == OrderStatus.Shipped)
            throw new InvalidOperationException("Cannot cancel a shipped order.");
        Status = OrderStatus.Cancelled;
    }
}
```

### Public — `[Module].Public/DTO/OrderDto.cs` and `[Module].Public/Abstractions/IOrderProvider.cs`

```csharp
// DTO: immutable, no domain entity exposure
public sealed record OrderDto(
    Guid Id,
    Guid CustomerId,
    string Status,
    decimal Total,
    DateTime CreatedAt);

// Interface: stable cross-module contract
// Return type uses Result<T> from [Product].Shared for consistent failure signalling
public interface IOrderProvider
{
    ValueTask<IReadOnlyList<OrderDto>> GetAllAsync(CancellationToken ct = default);
    ValueTask<OrderDto?> GetByIdAsync(Guid id, CancellationToken ct = default);
}
```

### Infrastructure — `[Module].Infrastructure/Repositories/OrderRepository.cs`

```csharp
// Dapper-based repository. The interface lives here (infrastructure-internal).
// The Public interface (IOrderProvider) is implemented separately in Application.
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<Order>> GetAllAsync(CancellationToken ct = default);
    Task<Order> CreateAsync(Order order, CancellationToken ct = default);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
}

public class OrderRepository(IDbConnection db) : IOrderRepository
{
    // Use parameterized queries. Never interpolate user input into SQL.
    public async Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        // Illustrative — use the appropriate Dapper call for your version
        const string sql = "SELECT * FROM orders.Orders WHERE Id = @Id";
        return await db.QuerySingleOrDefaultAsync<Order>(sql, new { Id = id });
    }

    public async Task<IEnumerable<Order>> GetAllAsync(CancellationToken ct = default)
    {
        const string sql = "SELECT * FROM orders.Orders";
        return await db.QueryAsync<Order>(sql);
    }

    public async Task<Order> CreateAsync(Order order, CancellationToken ct = default)
    {
        const string sql = @"
            INSERT INTO orders.Orders (Id, CustomerId, Status, Total, CreatedAt)
            VALUES (@Id, @CustomerId, @Status, @Total, @CreatedAt)";
        await db.ExecuteAsync(sql, order);
        return order;
    }

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        const string sql = "DELETE FROM orders.Orders WHERE Id = @Id";
        var rows = await db.ExecuteAsync(sql, new { Id = id });
        return rows > 0;
    }
}
```

### Application — `[Module].Application/Controllers/OrderController.cs`

```csharp
// MVC controller: thin. Business logic lives in services/repositories.
// Input validation is co-located here (e.g., via [ApiController] + data annotations,
// or a FluentValidation filter registered in the DI extension).
[ApiController]
[Route("api/orders")]
public sealed class OrderController(IOrderRepository repository) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var orders = await repository.GetAllAsync(ct);
        return Ok(orders);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var order = await repository.GetByIdAsync(id, ct);
        return order is null ? NotFound() : Ok(order);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        // Map from request (HTTP shape) to domain entity — never expose domain entity directly
        var order = new Order
        {
            Id = Guid.NewGuid(),
            CustomerId = request.CustomerId,
            Status = OrderStatus.Pending,
            Total = request.Total,
            CreatedAt = DateTime.UtcNow
        };
        var created = await repository.CreateAsync(order, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        var deleted = await repository.DeleteAsync(id, ct);
        return deleted ? NoContent() : NotFound();
    }
}

// Request type: HTTP concern — lives in Application alongside the controller
public sealed record CreateOrderRequest(Guid CustomerId, decimal Total);
```

### Application — `[Module].Application/Providers/OrderProvider.cs`

```csharp
// Implements the cross-module interface from [Module].Public.
// Delegates to Infrastructure; maps domain entities to DTOs.
public sealed class OrderProvider(IOrderRepository repository) : IOrderProvider
{
    public async ValueTask<IReadOnlyList<OrderDto>> GetAllAsync(CancellationToken ct = default)
    {
        var orders = await repository.GetAllAsync(ct);
        return orders.Select(ToDto).ToList();
    }

    public async ValueTask<OrderDto?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        var order = await repository.GetByIdAsync(id, ct);
        return order is null ? null : ToDto(order);
    }

    private static OrderDto ToDto(Order o) =>
        new(o.Id, o.CustomerId, o.Status.ToString(), o.Total, o.CreatedAt);
}
```

### Application — `[Module].Application/Extensions/OrderServiceExtensions.cs`

```csharp
// Single entry point for the host to register everything in this module.
public static class OrderServiceExtensions
{
    public static IServiceCollection AddOrderModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Strongly-typed config — reads from "OrderModule" section of appsettings
        var options = configuration
            .GetSection("OrderModule")
            .Get<OrderModuleOptions>() ?? new OrderModuleOptions();
        services.AddSingleton(options);

        // Register Dapper connection factory
        services.AddScoped<IDbConnection>(_ =>
            new SqlConnection(options.ConnectionString));

        // Register repository and provider
        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<IOrderProvider, OrderProvider>();

        // Health check for the module's database dependency
        services.AddHealthChecks()
            .AddSqlServer(options.ConnectionString, name: "orders-db");

        return services;
    }
}
```

---

## Migration Notes

**From N-tier monolith:** This template is the closest structural match to a traditional N-tier `Controller / Service / Repository` stack. The main differences are:
- The controller is scoped to one bounded context, not the entire application
- The repository is behind an interface (testable in isolation)
- Cross-module calls go through `IOrderProvider`, not through shared service classes

**From Big Ball of Mud:** Start here before moving to a more complex template. Extract one bounded context at a time. Use an Anti-Corruption Layer in `Infrastructure` to translate the legacy data shape into the module's domain model before retiring the legacy code.

**From microservices consolidation:** If the incoming microservice already used SQL + Dapper, this template is the lowest-friction landing zone. Verify that the service's domain model fits cleanly into the 4-layer structure before adopting a more complex template.

---

## Common Mistakes to Avoid

- Injecting `IDbConnection` or Dapper directly into the controller — keep data access in repositories
- Returning domain entities from the controller — always map to a response DTO
- Placing SQL strings in the controller or provider — SQL belongs in the repository
- Forgetting `CancellationToken` on async methods — always accept and forward it
- Using a shared `IDbConnection` registered as Singleton — connections must be Scoped or shorter
